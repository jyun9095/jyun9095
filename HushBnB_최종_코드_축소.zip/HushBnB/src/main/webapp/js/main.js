$(document).ready(function() {

   $("#menuMember").click(function() {

      if ($("#profileBox").css("visibility") != "visible"){
         $("#profileBox").css("visibility", "visible");
         $("#msgBox").css("visibility", "hidden");
      }
      else
         $("#profileBox").css("visibility", "hidden");
   });

   $("#menuMsg").click(function() {

      if ($("#msgBox").css("visibility") != "visible"){
         $("#msgBox").css("visibility", "visible");
         $("#profileBox").css("visibility", "hidden");
      }
      else
         $("#msgBox").css("visibility", "hidden");
   });
   
   $(".btnBoard").click(function(){
     location.href="/spring/board/noticelist.hush";
   });

});

//선택한 메세지 view
function moveMessageView(messageSeq) {
   location.href = "/spring/mypage/messageview.hush?seq=" + messageSeq;
}