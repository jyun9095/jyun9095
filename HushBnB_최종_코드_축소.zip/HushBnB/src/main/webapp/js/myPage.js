$(document).ready(function() {

	/*display: none;
	display: block;*/

	$("#itieraryMenu").click(function() {

		if ($("#itemList").css("display") == "none") {
			$("#itemList").css("display", "block");
		} else {
			$("#itemList").css("display", "none");
		}
	});

	$(".items").click(function() {

		$(".items ").css("background-color", "#337AB7");
		$(event.srcElement).css("background-color", "#C6DCEF");

		$(".items").css("color", "white");
		$(event.srcElement).css("color", "black");

	});

	$("#itinerary").click(function() {
		location.href="/spring/mypage/itinerary.hush";
	});

	$("#itineraryForm").click(function() {
		location.href="/spring/mypage/itineraryform.hush";
	});

	$("#itineraryList").click(function() {
		location.href="/spring/mypage/itinerarylist.hush";
	});

});