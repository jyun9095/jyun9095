package com.hush.main;

public class SearchDTO {
	
	private String citySeq;
	private String regionSeq;
	private String startDate;
	private String endDate;
	private String guestNum;
	private String price;
	
	public String getCitySeq() {
		return citySeq;
	}
	public void setCitySeq(String citySeq) {
		this.citySeq = citySeq;
	}
	public String getRegionSeq() {
		return regionSeq;
	}
	public void setRegionSeq(String regionSeq) {
		this.regionSeq = regionSeq;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getGuestNum() {
		return guestNum;
	}
	public void setGuestNum(String guestNum) {
		this.guestNum = guestNum;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}

}
