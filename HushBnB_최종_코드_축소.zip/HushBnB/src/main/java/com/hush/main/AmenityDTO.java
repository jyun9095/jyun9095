package com.hush.main;

public class AmenityDTO {
   private String internet;
   private String elevator;
   private String tv;
   private String washingMachine;
   private String hairDryer;
   private String pool;
   private String parkingLot;
   
   
   public String getInternet() {
      return internet;
   }
   public void setInternet(String internet) {
      this.internet = internet;
   }
   public String getElevator() {
      return elevator;
   }
   public void setElevator(String elevator) {
      this.elevator = elevator;
   }
   public String getTv() {
      return tv;
   }
   public void setTv(String tv) {
      this.tv = tv;
   }
   public String getWashingMachine() {
      return washingMachine;
   }
   public void setWashingMachine(String washingMachine) {
      this.washingMachine = washingMachine;
   }
   public String getHairDryer() {
      return hairDryer;
   }
   public void setHairDryer(String hairDryer) {
      this.hairDryer = hairDryer;
   }
   public String getPool() {
      return pool;
   }
   public void setPool(String pool) {
      this.pool = pool;
   }
   public String getParkingLot() {
      return parkingLot;
   }
   public void setParkingLot(String parkingLot) {
      this.parkingLot = parkingLot;
   }
   
   
   
}