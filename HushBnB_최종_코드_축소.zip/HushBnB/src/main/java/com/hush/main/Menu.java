package com.hush.main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class Menu {

   @Autowired
   private MainDAO dao;

   public HashMap<String, Object> menu(HttpSession session) {

      HashMap<String, Object> map = new HashMap<String, Object>();

      MemberDTO dto = new MemberDTO();
      List<MessageDTO> msgList = new ArrayList<MessageDTO>();

      // session.setAttribute("id", "hodu5637");
      String id = (String) session.getAttribute("id");
      System.out.println("id : " + id);

      if (id != null) { // 로그인 되어있으면
         dto = dao.checkId(id);

         System.out.println("img : " + dto.getImage());

         // 메세지 리스트 얻어오기
         msgList = dao.getMsg(id);

         SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd"); // ORACLE
         // 현재시간
         Calendar now = Calendar.getInstance();
         long nowTick = now.getTime().getTime(); // method chain

         for (int i = 0; i < msgList.size(); i++) {
            // 날짜처리
            String temp = msgList.get(i).getRegDate().substring(0, 10);
            msgList.get(i).setRegDate(temp);

            Date regdate;
            try {
               regdate = format.parse(msgList.get(i).getRegDate());
               long regdateTick = regdate.getTime();

               // 글쓴뒤 지나간 시간??
               long span = nowTick - regdateTick;
               System.out.println("span : " + span);
               System.out.println("span 시간: " + span/1000/60/60/24);

               if ((span / 1000 / 60 / 60 / 24) < 1) {
                  // 하루가 안지났으면 -> 새글
                  System.out.println("새글");
                  msgList.get(i).setIsNew(
                        "<img src='/spring/images/new.png' />");
               }
            } catch (ParseException e) {
               e.printStackTrace();
            }
            System.out.println(msgList.get(i).getIsNew());

            // 제목이 길면... 자르기
            String message = msgList.get(i).getMessage();

            if (message.length() > 5) {
               message = message.substring(0, 20) + "...";

               msgList.get(i).setMessage(message);
            }
         }
      }
      map.put("memberdto", dto);
      map.put("msgList", msgList);

      System.out.println("memberdto : " + map.get("memberdto"));

      return map;

   }
}