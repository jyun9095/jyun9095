package com.hush.main;

public class AccomQnADTO {
   
   private String seq;
   private String userId;
   private String managerId;
   private String codeNum;
   private String title;
   private String content;
   private String answer;
   private String regDate;
   private String readCount;
   private String id;
   
   
   
   
   

   public String getId() {
      return id;
   }
   public void setId(String id) {
      this.id = id;
   }
   public String getAnswer() {
      return answer;
   }
   public void setAnswer(String answer) {
      this.answer = answer;
   }
   public String getSeq() {
      return seq;
   }
   public void setSeq(String seq) {
      this.seq = seq;
   }
   public String getUserId() {
      return userId;
   }
   public void setUserId(String userId) {
      this.userId = userId;
   }
   public String getManagerId() {
      return managerId;
   }
   public void setManagerId(String managerId) {
      this.managerId = managerId;
   }
   public String getCodeNum() {
      return codeNum;
   }
   public void setCodeNum(String codeNum) {
      this.codeNum = codeNum;
   }
   public String getTitle() {
      return title;
   }
   public void setTitle(String title) {
      this.title = title;
   }
   public String getContent() {
      return content;
   }
   public void setContent(String content) {
      this.content = content;
   }
   public String getRegDate() {
      return regDate;
   }
   public void setRegDate(String regDate) {
      this.regDate = regDate;
   }
   public String getReadCount() {
      return readCount;
   }
   public void setReadCount(String readCount) {
      this.readCount = readCount;
   }
   
   
   

}