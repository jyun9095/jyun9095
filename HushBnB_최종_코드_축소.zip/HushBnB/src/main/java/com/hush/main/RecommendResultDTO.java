package com.hush.main;

public class RecommendResultDTO {
   private String startDate;
   private String endDate;
   private String guestNum;
   private String price;
   private String[] regionSeq;
   
   
   public String getPrice() {
      return price;
   }
   public void setPrice(String price) {
      this.price = price;
   }
   public String getStartDate() {
      return startDate;
   }
   public void setStartDate(String startDate) {
      this.startDate = startDate;
   }
   public String getEndDate() {
      return endDate;
   }
   public void setEndDate(String endDate) {
      this.endDate = endDate;
   }
   public String getGuestNum() {
      return guestNum;
   }
   public void setGuestNum(String guestNum) {
      this.guestNum = guestNum;
   }
   public String[] getRegionSeq() {
      return regionSeq;
   }
   public void setRegionSeq(String[] regionSeq) {
      this.regionSeq = regionSeq;
   }
   
}