package com.hush.main;

public class AttractionDTO {
   private String seq;
   private String regionSeq;
   private String image;
   private String name;
   private String address;
   private String description;
   public String getSeq() {
      return seq;
   }
   public void setSeq(String seq) {
      this.seq = seq;
   }
   public String getRegionSeq() {
      return regionSeq;
   }
   public void setRegionSeq(String regionSeq) {
      this.regionSeq = regionSeq;
   }
   public String getImage() {
      return image;
   }
   public void setImage(String image) {
      this.image = image;
   }
   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }
   public String getAddress() {
      return address;
   }
   public void setAddress(String address) {
      this.address = address;
   }
   public String getDescription() {
      return description;
   }
   public void setDescription(String description) {
      this.description = description;
   }
   
   
   
}