package com.hush.main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hush.mypage.ZzimDTO;

@Controller
public class MainController {

	@Autowired
	private MainDAO dao;

	@Autowired
	private Menu menu;

	private HashMap<String, Object> map; // 어떠한 메뉴던지

	// 네이버 지도 키
	private String key = "07968a24356513ca9fc6da086fd69114";

	@RequestMapping(value = "/main/main.hush", method = { RequestMethod.GET })
	public String main(HttpServletRequest req, HttpSession session,
			String citySeq) {

		List<CityDTO> cityList = dao.cityList();

		if (citySeq != null) {

			int citySeq_n = Integer.parseInt(citySeq);
			List<RegionDTO> regionList = dao.regionList(citySeq_n);
			req.setAttribute("regionList", regionList);
			req.setAttribute("citySeq", citySeq);

		}

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		req.setAttribute("cityList", cityList);

		return "main/main";
	}

	@RequestMapping(value = "/main/result.hush", method = { RequestMethod.POST })
	public String result(HttpServletRequest req, HttpSession session,
			SearchDTO dto) throws ParseException {

		session.setAttribute("searchResult", dto);

		System.out.println(dto.getStartDate()); // 2015-08-18
		System.out.println(dto.getEndDate()); // 2015-08-19
		System.out.println(dto.getRegionSeq()); // 42
		System.out.println(dto.getCitySeq()); // 3
		System.out.println(dto.getGuestNum()); // 1

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		/*
		 * Date startDate = null; Date endDate = null; startDate =
		 * format.parse(dto.getStartDate()); endDate =
		 * format.parse(dto.getEndDate());
		 */

		Calendar startDate = Calendar.getInstance();
		Calendar endDate = Calendar.getInstance();
		Calendar finishDate = Calendar.getInstance();

		finishDate.setTime(format.parse(dto.getStartDate()));
		startDate.setTime(format.parse(dto.getStartDate()));
		endDate.setTime(format.parse(dto.getEndDate()));

		System.out.println("startDate : " + startDate); // 2015-08-29
		System.out.println("endDate : " + endDate); // 2015-08-31
		System.out.println(endDate.get(Calendar.DAY_OF_YEAR)
				- startDate.get(Calendar.DAY_OF_YEAR)); // 243-241 = 2

		int nights = endDate.get(Calendar.DAY_OF_YEAR)
				- startDate.get(Calendar.DAY_OF_YEAR);

		List<AccommodationDTO> accomList = new ArrayList<AccommodationDTO>();
		List<String> dateList = new ArrayList<String>();

		for (int i = 0; i < nights; i++) {
			/*
			 * System.out .println("startDate : " + String.format("%tF",
			 * startDate)); System.out.println("finishDate : " +
			 * String.format("%tF", finishDate));
			 */

			dto.setStartDate(String.format("%tF", startDate));
			System.out.println("startDate : " + dto.getStartDate());

			List<AccommodationDTO> list = new ArrayList<AccommodationDTO>();
			list = dao.getAccommodation(dto);

			finishDate.add(Calendar.DATE, -7); // 딜 마감날짜
			System.out.println("finishDate : "
					+ String.format("%tF", finishDate));
			System.out
					.println("startDate : " + String.format("%tF", startDate));
			for (int j = 0; j < list.size(); j++) {
				list.get(j).setdDay(String.format("%tF", startDate));
				list.get(j).setFinishDay(String.format("%tF", finishDate));
			}

			dateList.add(String.format("%tF", startDate));
			startDate.add(Calendar.DATE, 1);

			accomList.addAll(list);
		}

		System.out.println("dateList : " + dateList);
		System.out.println("listSize() : " + accomList.size());

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		req.setAttribute("accomList", accomList); // 30 dDday
		req.setAttribute("dateList", dateList); // 2015-08-26 , 2015-08-27

		req.setAttribute("nights", nights);

		req.setAttribute("key", key);

		return "main/result";
	}

	@RequestMapping(value = "main/accominfo.hush", method = { RequestMethod.GET })
	public String accomInfo(HttpServletRequest req, HttpSession session,
			String codeNum, String type, String dDay) {

		AccommodationDTO dto = dao.getAccommodation(codeNum);
		AmenityDTO amenityDTO = dao.getAmenity(codeNum);
		DetailImgDTO detailImgDTO = dao.getDetailImg(codeNum);
		List<ReviewDTO> reviewList = dao.getReview(codeNum);
		List<AccomQnADTO> accomQnAList = dao.getAccommodationQnA(codeNum);
		List<AttractionDTO> attractionDTO = dao.getAttraction(dto
				.getRegionSeq());

		dto.setBreakFirst(dto.getBreakFirst().equals("n") ? "X" : "O");
		dto.setGender(dto.getGender().equals("F") ? "여" : "남");

		amenityDTO
				.setElevator(amenityDTO.getElevator().equals("n") ? "X" : "O");
		amenityDTO.setHairDryer(amenityDTO.getHairDryer().equals("n") ? "X"
				: "O");
		amenityDTO
				.setInternet(amenityDTO.getInternet().equals("n") ? "X" : "O");
		amenityDTO.setParkingLot(amenityDTO.getParkingLot().equals("n") ? "X"
				: "O");
		amenityDTO.setPool(amenityDTO.getPool().equals("n") ? "X" : "O");
		amenityDTO.setTv(amenityDTO.getTv().equals("n") ? "X" : "O");
		amenityDTO
				.setWashingMachine(amenityDTO.getWashingMachine().equals("n") ? "X"
						: "O");

		for (int i = 0; i < reviewList.size(); i++) {
			// 날짜, 엔터 전처리
			reviewList.get(i).setRegDate(
					reviewList.get(i).getRegDate().substring(0, 19));
			reviewList.get(i).setContent(
					reviewList.get(i).getContent().replace("\r\n", "<br />"));
		}

		for (int i = 0; i < accomQnAList.size(); i++) {
			// 날짜, 엔터 전처리
			accomQnAList.get(i).setRegDate(
					accomQnAList.get(i).getRegDate().substring(0, 19));
			accomQnAList.get(i).setContent(
					accomQnAList.get(i).getContent().replace("\r\n", "<br />"));
			if (accomQnAList.get(i).getAnswer() != null) {
				accomQnAList.get(i).setAnswer(
						accomQnAList.get(i).getAnswer()
								.replace("\r\n", "<br />"));
			}
		}

		map = menu.menu(session);
		boolean isManager = false;

		/*
		 * MemberDTO memberdto = (MemberDTO) map.get("memberdto");
		 * if(memberdto.getLv().equals("m")){ isManager = true; }
		 */

		req.setAttribute("type", type);

		req.setAttribute("dDay", dDay);

		req.setAttribute("accomdto", dto);
		req.setAttribute("amenitydto", amenityDTO);
		req.setAttribute("detailImgdto", detailImgDTO);
		req.setAttribute("reviewList", reviewList);
		req.setAttribute("accomQnAList", accomQnAList);
		req.setAttribute("attractiondto", attractionDTO);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		return "main/accomInfo";
	}

	@RequestMapping(value = "/main/addreview.hush", method = { RequestMethod.GET })
	public String addReview(HttpServletRequest req, HttpSession session,
			String codeNum) {

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		System.out.println("ADDREVEIW COENUM : " + codeNum);
		req.setAttribute("codeNum", codeNum);

		return "main/addReview";
	}

	@RequestMapping(value = "/main/addreviewok.hush", method = { RequestMethod.POST })
	public String addReviewOk(HttpServletRequest req, HttpSession session,
			ReviewDTO dto) {

		int result = 0;
		System.out.println("CODENUM! : " + dto.getCodeNum());
		dto.setId((String) session.getAttribute("id"));
		System.out.println("id : " + (String) session.getAttribute("id"));

		result = dao.addReview(dto);

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		req.setAttribute("result", result);
		req.setAttribute("codeNum", dto.getCodeNum());

		return "main/addReviewOk";
	}

	@RequestMapping(value = "/main/addquestion.hush", method = { RequestMethod.GET })
	public String addQuesiont(HttpServletRequest req, HttpSession session,
			String codeNum) {

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		req.setAttribute("codeNum", codeNum);

		return "main/addQuestion";
	}

	@RequestMapping(value = "/main/addquestionok.hush", method = { RequestMethod.POST })
	public String addQuestionOk(HttpServletRequest req, HttpSession session,
			AccomQnADTO dto) {

		int result = 0;
		dto.setId((String) session.getAttribute("id"));

		result = dao.addQuestion(dto);

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		req.setAttribute("result", result);
		req.setAttribute("codeNum", dto.getCodeNum());

		return "main/addQuestionOk";
	}

	@RequestMapping(value = "/main/accomanswer.hush", method = { RequestMethod.POST })
	public String accomAnswer(HttpServletRequest req, HttpSession session,
			AccomAnswerDTO dto) {

		int result = 0;
		dto.setId((String) session.getAttribute("id"));

		System.out.println("id : " + dto.getId());
		System.out.println("accomSeq : " + dto.getAccommodationSeq());
		System.out.println("answer : " + dto.getAnswer());
		System.out.println("codeNum : " + dto.getCodeNum());
		// id : hodu5637
		// accomSeq : 21
		// answer : 답변이당~
		// codeNum : BU001

		result = dao.addAnswer(dto);

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		req.setAttribute("result", result);
		req.setAttribute("codeNum", dto.getCodeNum());

		return "main/addAnswerOk";
	}

	@RequestMapping(value = "/main/zzimadd.hush", method = { RequestMethod.POST })
	public String zzimAdd(HttpServletRequest req, HttpSession session,
			ZzimDTO dto) {

		int result = 0;

		if (session.getAttribute("id") == null) {
			req.setAttribute("result", result);
		} else {
			result = 1;
			dto.setId(session.getAttribute("id").toString());

			System.out.println("codeNum : " + dto.getAccommodationCodeNum()); // BU004
			System.out.println("dDay : " + dto.getdDay()); // 2015-08-27
			System.out.println("id : " + dto.getId()); // hodu5637

			dao.addZzim(dto);

			req.setAttribute("result", result);
		}

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		return "main/zzimAdd";
	}

	@RequestMapping(value = "/main/precash.hush", method = { RequestMethod.POST })
	public String precash(HttpServletRequest req, HttpSession session) {

		String codeNum = req.getParameter("codeNum");
		String zzimSeq = req.getParameter("zzimSeq");
		String id = (String) session.getAttribute("id");

		Calendar now = Calendar.getInstance();
		System.out.println("now : " + String.format("%tF", now));
		now.add(Calendar.DATE, 7); // 접속날짜에서 7일 더한거

		String nowDay = String.format("%tF", now);
		System.out.println("nowDay : " + nowDay);

		HashMap<String, String> map2 = new HashMap<String, String>();

		map2.put("nowDay", nowDay);
		map2.put("codeNum", codeNum);
		map2.put("id", id);

		PrecashDTO dto = dao.precash(map2);

		dto.setdDay(dto.getdDay().substring(0, 10));

		System.out.println("dto image : " + dto.getMainImg());

		req.setAttribute("dto", dto);

		map = menu.menu(session);

		System.out.println("++++++++++++++++++++++zzimSeq : " + zzimSeq);

		req.setAttribute("zzimSeq", zzimSeq);
		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		return "main/precash";
	}

	@RequestMapping(value = "/main/payment.hush", method = { RequestMethod.POST })
	public String payment(HttpServletRequest req, HttpSession session,
			PaymentDTO dto) {

		// seq accommodationCodeNum detailItinerarySeq id zzimSeq ch;

		String id = (String) session.getAttribute("id");
		dto.setId(id);

		String price = req.getParameter("price");

		HashMap<String, String> map2 = new HashMap<String, String>();
		map2.put("id", id);
		map2.put("zzimSeq", dto.getZzimSeq());

		Integer detailItinerarySeq = dao.getDetailItinerarySeq(map2);

		if (detailItinerarySeq == null) {
			dto.setDetailItinerarySeq("37");
		} else {
			dto.setDetailItinerarySeq(detailItinerarySeq + "");
		}

		System.out.println("+++++++++++++++++++++++++++++++++++++++++");
		System.out.println("ZzimSeq : " + dto.getZzimSeq());
		System.out.println("DetailItinerarySeq : "
				+ dto.getDetailItinerarySeq());
		System.out.println("Id : " + dto.getId());
		System.out.println("AccommodationCodeNum : "
				+ dto.getAccommodationCodeNum());

		map = menu.menu(session);

		req.setAttribute("price", price);
		req.setAttribute("dto", dto);
		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		return "main/payment";
	}

	@RequestMapping(value = "/main/paymentok.hush", method = { RequestMethod.POST })
	public String paymentOk(HttpServletRequest req, PaymentDTO dto,
			HttpSession session) {

		String id = (String) session.getAttribute("id");
		dto.setId(id);

		System.out.println("ㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇ");
		System.out.println("id : " + dto.getId());
		System.out.println("AccommodationCodeNum : "
				+ dto.getAccommodationCodeNum());
		System.out.println("DetailItinerarySeq : "
				+ dto.getDetailItinerarySeq());
		System.out.println("ZzimSeq : " + dto.getZzimSeq());

		int result = dao.addPayment(dto);
		System.out.println("result : " + result);
		
		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		req.setAttribute("result", result);

		return "main/paymentOk";
	}

	@RequestMapping(value = "/main/paymentresult.hush", method = { RequestMethod.GET })
	public String paymentResult(HttpSession session, HttpServletRequest req) {

		System.out.println("결제완료!!!!");

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		
		return "main/paymentResult";
	}

	@RequestMapping(value = "/main/recommendresult.hush", method = { RequestMethod.POST })
	public String recommendResult(HttpServletRequest req, HttpSession session,
			RecommendResultDTO dto) {

		System.out.println("startDate : " + dto.getStartDate());
		System.out.println("endDate : " + dto.getEndDate());
		System.out.println("guestNum : " + dto.getGuestNum());
		System.out.println("regionSeq.length : " + dto.getRegionSeq().length);

		for (int i = 0; i < dto.getRegionSeq().length; i++) {
			System.out
					.printf("regionSeq %d : %s\r\n", i, dto.getRegionSeq()[i]);
		}

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

		Calendar startDate = Calendar.getInstance();
		Calendar endDate = Calendar.getInstance();

		try {
			startDate.setTime(format.parse(dto.getStartDate()));
			endDate.setTime(format.parse(dto.getEndDate()));
		} catch (ParseException e) {
			e.printStackTrace();
		}

		int nights = endDate.get(Calendar.DAY_OF_YEAR)
				- startDate.get(Calendar.DAY_OF_YEAR);

		System.out.println("nights : " + nights);

		List<AccommodationDTO> accomList = new ArrayList<AccommodationDTO>();
		List<String> dateList = new ArrayList<String>();

		for (int i = 0; i < nights; i++) {
			dto.setStartDate(String.format("%tF", startDate));
			System.out.println("startDate : " + dto.getStartDate());

			List<AccommodationDTO> list = new ArrayList<AccommodationDTO>();
			SearchDTO sdto = new SearchDTO();
			sdto.setStartDate(String.format("%tF", startDate));
			sdto.setGuestNum(dto.getGuestNum());
			sdto.setRegionSeq(dto.getRegionSeq()[i]);
			sdto.setPrice(dto.getPrice());

			list = dao.getRecommendAccommodation(sdto);

			if (list != null) {

				for (int j = 0; j < list.size(); j++) {
					list.get(j).setdDay(String.format("%tF", startDate));
				}

				dateList.add(String.format("%tF", startDate));
				startDate.add(Calendar.DATE, 1);

				accomList.addAll(list);
			}
		}

		System.out.println("accomList Size : " + accomList.size());
		System.out.println(accomList);

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		req.setAttribute("accomList", accomList); // 30 dDday
		req.setAttribute("dateList", dateList); // 2015-08-26 , 2015-08-27

		req.setAttribute("nights", nights);

		req.setAttribute("key", key);

		System.out.println("여기까지됨 ");

		return "main/recommendResult";
	}
}