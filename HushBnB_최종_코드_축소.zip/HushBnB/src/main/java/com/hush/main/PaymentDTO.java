package com.hush.main;

public class PaymentDTO {

	private String seq;
	private String accommodationCodeNum;
	private String detailItinerarySeq;
	private String id;
	private String zzimSeq;
	private String ch;

	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}

	public String getAccommodationCodeNum() {
		return accommodationCodeNum;
	}

	public void setAccommodationCodeNum(String accommodationCodeNum) {
		this.accommodationCodeNum = accommodationCodeNum;
	}

	public String getDetailItinerarySeq() {
		return detailItinerarySeq;
	}

	public void setDetailItinerarySeq(String detailItinerarySeq) {
		this.detailItinerarySeq = detailItinerarySeq;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getZzimSeq() {
		return zzimSeq;
	}

	public void setZzimSeq(String zzimSeq) {
		this.zzimSeq = zzimSeq;
	}

	public String getCh() {
		return ch;
	}

	public void setCh(String ch) {
		this.ch = ch;
	}

}
