package com.hush.main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hush.auth.AuthDTO;
import com.hush.mypage.ZzimDTO;

@Repository
public class MainDAO {

	@Autowired
	private SqlSessionTemplate sql;

	public MemberDTO checkId(String id) {

		MemberDTO dto = sql.selectOne("main.checkid", id);

		return dto;
	}

	public List<CityDTO> cityList() {

		List<CityDTO> list = new ArrayList<CityDTO>();

		list = sql.selectList("main.cityList");

		return list;
	}

	public List<RegionDTO> regionList(int citySeq_n) {

		return sql.selectList("main.regionList", citySeq_n);
	}

	public List<AccommodationDTO> getAccommodation(SearchDTO dto) {

		return sql.selectList("main.accommodationList", dto);

	}

	// 숙박 코드로 찾는 숙박 상세정보 Overloading
	public AccommodationDTO getAccommodation(String codeNum) {

		return sql.selectOne("main.accommodation", codeNum);
	}

	public List<MessageDTO> getMsg(String id) {

		return sql.selectList("main.messageList", id);
	}

	// 숙박 편의 시설을 얻는 메소드
	public AmenityDTO getAmenity(String codeNum) {

		return sql.selectOne("main.amenity", codeNum);
	}

	public DetailImgDTO getDetailImg(String codeNum) {
		return sql.selectOne("main.detailImg", codeNum);
	}

	// 숙박에 대한 후기를 가져오는 메소드
	public List<ReviewDTO> getReview(String codeNum) {
		return sql.selectList("main.review", codeNum);
	}

	// 리뷰추가하는 메소드
	public int addReview(ReviewDTO reviewDTO) {

		System.out.println(reviewDTO.getCodeNum());
		System.out.println(reviewDTO.getId());
		System.out.println(reviewDTO.getTitle());
		System.out.println(reviewDTO.getContent());
		return sql.insert("main.addReview", reviewDTO);

	}

	public List<AccomQnADTO> getAccommodationQnA(String codeNum) {
		return sql.selectList("main.accomQnA", codeNum);
	}

	public int addQuestion(AccomQnADTO dto) {

		return sql.insert("main.accomQuestion", dto);
	}

	public int addAnswer(AccomAnswerDTO dto) {
		return sql.insert("main.addAnswer", dto);
	}

	public List<AttractionDTO> getAttraction(String regionSeq) {
		System.out.println(regionSeq);
		return sql.selectList("main.attraction", regionSeq);
	}

	public int addZzim(ZzimDTO dto) {
		return sql.insert("main.addZzim", dto);
	}

	public PrecashDTO precash(HashMap<String, String> map) {
		return sql.selectOne("main.precash", map);
	}

	public Integer getDetailItinerarySeq(HashMap<String, String> map2) {

		return sql.selectOne("main.getDetailItinerarySeq", map2);
	}

	public int addPayment(PaymentDTO dto) {

		return sql.insert("main.addPayment", dto);
	}

	public List<AccommodationDTO> getRecommendAccommodation(SearchDTO sdto) {
		return sql.selectList("main.recommendAccommodationList", sdto);
	}

}