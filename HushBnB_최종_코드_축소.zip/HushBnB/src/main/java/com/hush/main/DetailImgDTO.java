package com.hush.main;

public class DetailImgDTO {
   
   private String detailImg1;
   private String detailImg2;
   private String detailImg3;
   private String detailImg4;
   private String detailImg5;
   public String getDetailImg1() {
      return detailImg1;
   }
   public void setDetailImg1(String detailImg1) {
      this.detailImg1 = detailImg1;
   }
   public String getDetailImg2() {
      return detailImg2;
   }
   public void setDetailImg2(String detailImg2) {
      this.detailImg2 = detailImg2;
   }
   public String getDetailImg3() {
      return detailImg3;
   }
   public void setDetailImg3(String detailImg3) {
      this.detailImg3 = detailImg3;
   }
   public String getDetailImg4() {
      return detailImg4;
   }
   public void setDetailImg4(String detailImg4) {
      this.detailImg4 = detailImg4;
   }
   public String getDetailImg5() {
      return detailImg5;
   }
   public void setDetailImg5(String detailImg5) {
      this.detailImg5 = detailImg5;
   }

}