package com.hush.main;

public class AccomQuestionDTO {
   private String seq;
   private String id;
   private String codeNum;
   private String title;
   public String getSeq() {
      return seq;
   }
   public void setSeq(String seq) {
      this.seq = seq;
   }
   public String getId() {
      return id;
   }
   public void setId(String id) {
      this.id = id;
   }
   public String getCodeNum() {
      return codeNum;
   }
   public void setCodeNum(String codeNum) {
      this.codeNum = codeNum;
   }
   public String getTitle() {
      return title;
   }
   public void setTitle(String title) {
      this.title = title;
   }
   
   

}