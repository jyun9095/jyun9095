package com.hush.board;

public class BoardhomepageDTO {
   
   private String seq;
   private String id;
   private String title;
   private String content;
   private String readcount;
   private String regDate;
   private String IsNew;
   
   
   public String getSeq() {
      return seq;
   }
   public void setSeq(String seq) {
      this.seq = seq;
   }
   public String getId() {
      return id;
   }
   public void setId(String id) {
      this.id = id;
   }
   public String getTitle() {
      return title;
   }
   public void setTitle(String title) {
      this.title = title;
   }
   public String getContent() {
      return content;
   }
   public void setContent(String content) {
      this.content = content;
   }
   public String getReadcount() {
      return readcount;
   }
   public void setReadcount(String readcount) {
      this.readcount = readcount;
   }
   public String getRegDate() {
      return regDate;
   }
   public void setRegDate(String regDate) {
      this.regDate = regDate;
   }
   public String getIsNew() {
      return IsNew;
   }
   public void setIsNew(String isNew) {
      IsNew = isNew;
   }

}