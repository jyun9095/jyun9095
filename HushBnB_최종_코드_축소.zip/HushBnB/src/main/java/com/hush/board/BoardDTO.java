package com.hush.board;

import org.springframework.web.multipart.MultipartFile;

public class BoardDTO {

   private String seq;
   private String id;

   private String title;
   private String content;

   private String readcount;
   private String regDate;

   private MultipartFile attch;

   private String fileName;
   private String image;

   // <img /> 태그 넣을 공간
   private String isNew; // DB값이 아님****

   public MultipartFile getAttch() {
      return attch;
   }

   public void setAttch(MultipartFile attch) {
      this.attch = attch;
   }

   public String getFileName() {
      return fileName;
   }

   public void setFileName(String fileName) {
      this.fileName = fileName;
   }

   public String getImage() {
      return image;
   }

   public void setImage(String image) {
      this.image = image;
   }

   public String getId() {
      return id;
   }

   public void setId(String id) {
      this.id = id;
   }

   public String getSeq() {
      return seq;
   }

   public void setSeq(String seq) {
      this.seq = seq;
   }

   public String getTitle() {
      return title;
   }

   public void setTitle(String title) {
      this.title = title;
   }

   public String getContent() {
      return content;
   }

   public void setContent(String content) {
      this.content = content;
   }

   public String getReadcount() {
      return readcount;
   }

   public void setReadcount(String readcount) {
      this.readcount = readcount;
   }

   public String getRegDate() {
      return regDate;
   }

   public void setRegDate(String regDate) {
      this.regDate = regDate;
   }

   public String getIsNew() {
      return isNew;
   }

   public void setIsNew(String isNew) {
      this.isNew = isNew;
   }

}