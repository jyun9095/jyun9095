package com.hush.board;

public class BoardproductDTO {
   
   private String id;
   private String seq;
   private String title;
   private String content;
   private String images;
   private String codenum;
   private String readcount;
   private String regDate;
   private String IsNew;
   
   
   public String getIsNew() {
      return IsNew;
   }
   public void setIsNew(String isNew) {
      IsNew = isNew;
   }
   public String getId() {
      return id;
   }
   public void setId(String id) {
      this.id = id;
   }
   public String getSeq() {
      return seq;
   }
   public void setSeq(String seq) {
      this.seq = seq;
   }
   public String getTitle() {
      return title;
   }
   public void setTitle(String title) {
      this.title = title;
   }
   public String getContent() {
      return content;
   }
   public void setContent(String content) {
      this.content = content;
   }
   public String getImages() {
      return images;
   }
   public void setImages(String images) {
      this.images = images;
   }
   public String getCodenum() {
      return codenum;
   }
   public void setCodenum(String codenum) {
      this.codenum = codenum;
   }
   public String getReadcount() {
      return readcount;
   }
   public void setReadcount(String readcount) {
      this.readcount = readcount;
   }
   public String getRegDate() {
      return regDate;
   }
   public void setRegDate(String regDate) {
      this.regDate = regDate;
   }
   
   

}