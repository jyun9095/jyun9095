package com.hush.board;

public class BoardproductCommentDTO {
   
   private String seq;
   private String id;
   private String answer;
   private String accommodationQuestionSeq;
   
   
   public String getSeq() {
      return seq;
   }
   public void setSeq(String seq) {
      this.seq = seq;
   }
   public String getId() {
      return id;
   }
   public void setId(String id) {
      this.id = id;
   }
   public String getAnswer() {
      return answer;
   }
   public void setAnswer(String answer) {
      this.answer = answer;
   }
   public String getAccommodationQuestionSeq() {
      return accommodationQuestionSeq;
   }
   public void setAccommodationQuestionSeq(String accommodationQuestionSeq) {
      this.accommodationQuestionSeq = accommodationQuestionSeq;
   }
   

}