package com.hush.board;

import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hush.auth.FileManager;
import com.hush.main.AccommodationDTO;
import com.hush.main.Menu;

@Controller
public class BoardController {

	@Autowired
	private BoardDAO dao;

	// 의존주입
	@Resource(name = "fileManager")
	private FileManager fileManager;

	@Autowired
	private Menu menu;

	private HashMap<String, Object> map; // 어떠한 메뉴던지

	// 공지사항 유저버전~!!!
	// 공지사항 목록 보이기

	@RequestMapping(value = "/board/noticelist.hush", method = { RequestMethod.GET })
	public String nlist(HttpServletRequest req, HttpSession session) {

		// 공지사항 페이징
		// - noticelist.hush -> noticelist.hush?page=1
		// - noticelist.hush?page=5

		int nowpage = 0; // 현재 페이지 번호 (잠시저장)
		int totalCount = 0; // 총 게시물 수
		int totalPage = 0; // 총 페이지 수
		int pageSize = 10; // 한페이지당 게시물 수
		int n = 0, loop = 0;
		int start = 0, end = 0;
		int blockSize = 10;

		String page = req.getParameter("page");

		if (page == null) {
			nowpage = 1;
		} else {

			nowpage = Integer.parseInt(page);
		}

		// nowpage-> 지금 출력 페이지 번호

		// 가져올 게시물의 범위 결정

		start = ((nowpage - 1) * pageSize) + 1;
		end = start + pageSize - 1;

		// 1. 목록보기(list.action)
		// 2. 검색하기(list.action?column=name&word=홍길동)

		boolean isSearch = false;

		String column = req.getParameter("column");
		String word = req.getParameter("word");
		HashMap<String, String> nmap = new HashMap<String, String>();

		if (column != null && word != null) {
			isSearch = true;
			nmap.put("column", column);
			nmap.put("word", word);

		}
		// 페이지바~
		nmap.put("start", start + "");
		nmap.put("end", end + "");

		List<BoardDTO> nlist = null; // 목록리스트

		nlist = dao.nlist(nmap);
		nlist = dao.nlist(nmap);

		// 데이터 검색
		for (int i = 0; i < nlist.size(); i++) {
			BoardDTO dto = nlist.get(i); // 글 1개

			// 자르기 전의 시각으로 구분지어야한다***
			// 최신글 표시 -> 1일, 12시간, 7일 등..
			// 현재 시간 - 글쓴 시간 -> tick값 연산
			// Date datoe = Calendar.getTime();
			// long tick = date.getTime(); -> 시각을 ms로 계산한 값

			// 현재시간
			Calendar now = Calendar.getInstance();
			long nowTick = now.getTime().getTime();

			// 글쓴시간(문자열 -> 날짜 시간형)
			SimpleDateFormat format = new SimpleDateFormat(
					"yyyy-MM-dd HH:mm:ss"); // Oracle

			try {
				// java.util.Date
				Date regdate = format.parse(dto.getRegDate());

				long regdateTick = regdate.getTime();

				// 글쓴 뒤 지나간 시간??
				long span = nowTick - regdateTick; // 시간 = 시각 - 시각

				if ((span / 1000 / 60 / 60) < 24) { // 글쓴지 하루가 안 지났습니까?
					// System.out.println("새글");
					dto.setIsNew("<img src='/spring/images/new.png' />");
				}

			} catch (Exception e) {
				System.out.println(e.toString());
			}

			// 날짜 처리
			String temp = dto.getRegDate().substring(0, 10);
			dto.setRegDate(temp);

			// 제목이 길면.. 자르기
			String title = dto.getTitle();

			if (title.length() > 25)
				title = title.substring(0, 24) + "...";

			dto.setTitle(title);

			// 제목이 검색중이면.. 검색어 부각
			if (isSearch && column.equals("title")) {
				title = dto.getTitle();

				// 이글은 테스트 입니다.

				// 이글은 <span style='background-color:yellow;color:red;'>
				// 테스트</span> 입니다.

				title = title.replace(word,
						"<span style='background-color:yellow;color:red;'>"
								+ word + "</span>");
				dto.setTitle(title);
			}
		}// for ***

		// 페이징
		// 총 페이지 수 ?
		totalCount = dao.getTotalCount(); // 124
		totalPage = (int) Math.ceil((double) totalCount / pageSize); // 무조건
		// 올림(3.1->4)

		// 페이비바 생성
		String pagebar = "";

		pagebar += "<nav id='nav1'><ul class='pagination'>";

		/*
		 * for (int i=1; i< totalPage; i++) { pagebar +=
		 * String.format("<li><a href='#'>%d</a></li>",i); }
		 */
		// blockSize : 한번에 보여질 페이지 최대 갯수

		// 페이지 번호를 만들기 위한 루프 변수
		loop = 1;
		// 페이지 출력 번호 변수(페이지 번호)
		// 5페이지 ->1
		// 8페이지 ->1
		// 10 페이지 -> 1
		// 11~20페이지는 -> 11
		n = ((nowpage - 1) / blockSize) * blockSize + 1;

		// 이전 10페이지
		if (n == 1) {
			pagebar += String
					.format("<li class='disabled'><a href='#' aria-label='Previous'><span aria-hidden='true'>&laquo;</span></a></li>",
							n - 1);
		} else {
			pagebar += String
					.format("<li><a href='/spring/board/noticelist.hush?page=%d' aria-label='Previous'><span aria-hidden='true'>&laquo;</span></a></li>",
							n - 1);
		}
		while (!(loop > blockSize || n > totalPage)) {

			if (n == nowpage) {
				pagebar += String.format(
						"<li class='active'><a href='#'>%d</a></li>", n);

			} else {
				pagebar += String
						.format("<li><a href='/spring/board/noticelist.hush?page=%d'>%d</a></li>",
								n, n);

			}
			loop++;
			n++;
		}

		// 다음 10페이지

		if (n > totalPage) {
			pagebar += String
					.format("<li class='disabled'><a href='#' aria-label='Next'><span aria-hidden='true'>&raquo;</span></a></li>",
							n);
		} else {
			pagebar += String
					.format("<li><a href='/spring/board/noticelist.hush?page=%d' aria-label='Next'><span aria-hidden='true'>&raquo;</span></a></li>",
							n);
		}
		pagebar += "</ul></nav>";

		String id = (String) session.getAttribute("id");
		int result = 0;

		if (id != null) {
			if (id.equals("hushAdmin")) {

				result = 1;
			}
		}

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		req.setAttribute("result", result);
		req.setAttribute("nlist", nlist);
		req.setAttribute("nmap", nmap);
		req.setAttribute("pagebar", pagebar);
		return "board/noticeList";
	}

	// 공지사항 글쓰기
	@RequestMapping(value = "/board/noticeadd.hush", method = { RequestMethod.GET })
	public String nadd(HttpServletRequest req, HttpSession session) {

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		
		return "board/noticeAdd";
	}

	// 공지사항 글쓰기 완료
	@RequestMapping(value = "/board/noticeAddok.hush", method = { RequestMethod.POST })
	public String addok(HttpServletRequest req, BoardDTO dto,
			HttpSession session) { // 1.

		// 파일 첨부 작업
		String root = session.getServletContext().getRealPath("/");
		String path = root + "images/notice";

		// 저장 할 파일명
		String newFileName = "";

		// 첨부 파일이 잇는지?
		if (!dto.getAttch().isEmpty()) {
			// 첨부파일을 서버에 저장하기
			byte[] bytes = null;

			try {
				bytes = dto.getAttch().getBytes();

				// 실제파일저장 + 저장 파일명 반환
				newFileName = fileManager.doFileUpload(bytes, dto.getAttch()
						.getOriginalFilename(), path);

				// 추가 작업
				// - 사용자가 첨부한 원본 파일명
				dto.setImage(dto.getAttch().getOriginalFilename());
				// - 실제 서버에 저장되는 파일명
				dto.setFileName(newFileName); // 20150825105124256019534376722.jpg

				// tick 값을 사용하므로서 이름 충돌 방지

			} catch (Exception e) {
				System.out.println(e.toString());
			}
		} else {
			dto.setImage("");
			dto.setFileName("");

		}

		// 1. 데이터 가져오기(DTO) - 전처리
		// 2. DAO 위임(insert)
		// 3. 완료 메시지 -> JSP 호출(위임)

		// 2.
		int result = dao.nadd(dto); // 글쓰기

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		
		req.setAttribute("result", result);

		return "board/noticeAddok";
	}

	// 공지사항 글 보기
	@RequestMapping(value = "/board/noticeview.hush", method = { RequestMethod.GET })
	public String view(HttpServletRequest req, String seq, HttpSession session) {

		// 1. 데이터 가져오기(view.action?seq=1)
		// 2. DAO위임(select)
		// 3. 결과값 DTO 반환 -> JSP 호출

		// 조회수 처리
		// HttpSession session = req.getSession(); -> 파라미터로 받는거랑 같아
		session.setAttribute("read", "n");

		// 새로고침으로 인한 조회수 증가 막기***********
		if (session.getAttribute("read") != null) { // list를 통해 들어온 경우에만
			if (session.getAttribute("read").toString().equals("n")) {
				// 조회수 증가(update)
				dao.noticeCount(seq); // 글번호 넘겨줘
				session.setAttribute("read", "y");
			}
		}

		// 2.
		BoardDTO dto = dao.nview(seq);

		// 일반적으로 태그작성 자체를 막아
		// 자바스크립트도 다 건드릴수 있자나 망해*********

		// <script>방지
		dto.setContent(dto.getContent().replace("<script", "&lt;script")
				.replace("</script>", "&lt;/script&gt;"));

		// 글내용의 엔터값 처리 -> 순서2***
		dto.setContent(dto.getContent().replace("\n", "<br />"));

		// 시간 조작 -> 뒤에 0 제거
		dto.setRegDate(dto.getRegDate().substring(0, 19));

		// 첨부파일이 이미지면.. 본문출력
		// cat.04.jpg
		if (dto.getImage() != null) {
			String file = dto.getImage();
			System.out.println(file + "★★★★★");
			System.out.println(!file.equals(" "));
			if (!file.equals(" ")) {

				String ext = file.substring(file.lastIndexOf(".")); // .jpg
				// 뒤에서부터
				// .까지 자른다.
				// System.out.println(exe);
				ext = ext.toLowerCase(); // 모두 소문자로
				if (ext.equals(".jpg") || ext.equals("jpeg")
						|| ext.equals(".png") || ext.equals(".gif")) {
					String content = dto.getContent();
					content = String
							.format("<img src='/spring/images/notice/%s' style='display : block; margin:20px auto; padding:3px; border : 1px solid gray; width: 600px; height: 350px;'/>",
									dto.getFileName())
							+ content;
					dto.setContent(content);
				}
			}
		}

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		
		req.setAttribute("dto", dto);
		return "board/noticeview";
	}

	// 공지사항 수정하기 화면 볼때
	@RequestMapping(value = "/board/noticeedit.hush", method = { RequestMethod.GET })
	public String nedit(HttpServletRequest req, String seq, HttpSession session) { // 1.
		// edit.action?seq=5

		// 1. 데이터 가져오기(seq)
		// 2. DAO 위임(select) - 글 1개
		// 3. 글 1개 -> JSP 호출

		// 먼저 기존 데이터를 가져와
		BoardDTO dto = dao.nview(seq);

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		
		req.setAttribute("dto", dto);

		return "board/noticeedit";
	}

	// 수정완료할때
	@RequestMapping(value = "/board/noticeeditok.hush", method = { RequestMethod.POST })
	public String neditok(HttpServletRequest req, BoardDTO dto,
			HttpSession session) {

		// 파일 첨부 작업
		String root = session.getServletContext().getRealPath("/");
		String path = root + "images/notice";

		// 저장 할 파일명
		String newFileName = "";

		// 첨부 파일이 잇는지?
		if (!dto.getAttch().isEmpty()) {
			// 첨부파일을 서버에 저장하기
			byte[] bytes = null;

			try {
				bytes = dto.getAttch().getBytes();

				// 실제파일저장 + 저장 파일명 반환
				newFileName = fileManager.doFileUpload(bytes, dto.getAttch()
						.getOriginalFilename(), path);

				// 추가 작업
				// - 사용자가 첨부한 원본 파일명
				dto.setImage(dto.getAttch().getOriginalFilename());
				// - 실제 서버에 저장되는 파일명
				dto.setFileName(newFileName); // 20150825105124256019534376722.jpg

				// tick 값을 사용하므로서 이름 충돌 방지

			} catch (Exception e) {
				System.out.println(e.toString());
			}
		} else {
			dto.setImage("");
			dto.setFileName("");

		}

		// 1. 데이터 가져오기(BoardDTO)
		// 2. DAO 위임 -> DB작업(update)
		// 3. JSP호출

		int result = 0;

		result = dao.nedit(dto);
		System.out.println(result);

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		
		req.setAttribute("result", result);
		req.setAttribute("seq", dto.getSeq()); // 다시 수정한 글로 돌아갈거니깡

		return "board/noticeeditok";
	}

	// 첨부 파일 다운로드 (브라우저가 직접 열지 못하도록)
	@RequestMapping(value = "/board/download.hush", method = { RequestMethod.GET })
	public void download(HttpServletRequest req, HttpServletResponse resp,
			HttpSession session) {

		// download.action?fileName=20150825105124256019534376722.jpg&orgFileName=19500.jpg
		String fileName = req.getParameter("fileName");
		String image = req.getParameter("image");

		String root = session.getServletContext().getRealPath("/");
		String path = root + "images/notice";

		boolean flag = false;

		// 파일 다운로드 ★★★★
		flag = fileManager.doFileDownload(fileName, image, path, resp);

		// 실패
		if (!flag) {
			resp.setContentType("text/html;charset=UTF-8");
			PrintWriter writer = null;

			try {
				writer = resp.getWriter();
				writer.println("<script>alert('파일 다운로드 실패 !!');</script>");
				writer.close();
			} catch (Exception e) {
				System.out.println("file : " + e.toString());
			}
		}
	}

	// 공지사항 삭제
	@RequestMapping(value = "/board/noticedel.hush", method = { RequestMethod.GET })
	public String ndel(HttpServletRequest req, String seq, HttpSession session) {

		int result = 0;

		result = dao.ndel(seq);
		System.out.println(result);
		
		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		
		req.setAttribute("result", result);

		return "board/noticedel";
	}

	// 여기까지~!! 공지사항 ~!!!

	// ------------------------------------------------------------------------------------------------
	// 상품 Q&A 유저버전~!!!

	// 상품 Q&A 목록 보이기

	@RequestMapping(value = "/board/productlist.hush", method = { RequestMethod.GET })
	public String plist(HttpServletRequest req, HttpSession session) {

		// 공지사항 페이징
		// - productlist.hush -> noticelist.hush?page=1
		// - productlist.hush?page=5

		int nowpage = 0; // 현재 페이지 번호 (잠시저장)
		int totalCount = 0; // 총 게시물 수
		int totalPage = 0; // 총 페이지 수
		int pageSize = 10; // 한페이지당 게시물 수
		int n = 0, loop = 0;
		int start = 0, end = 0;
		int blockSize = 10;

		String page = req.getParameter("page");

		if (page == null) {
			nowpage = 1;
		} else {

			nowpage = Integer.parseInt(page);
		}

		// nowpage-> 지금 출력 페이지 번호

		// 가져올 게시물의 범위 결정

		start = ((nowpage - 1) * pageSize) + 1;
		end = start + pageSize - 1;

		// 1. 목록보기(list.action)
		// 2. 검색하기(list.action?column=name&word=홍길동)

		boolean isSearch = false;

		String column = req.getParameter("column");
		String word = req.getParameter("word");
		HashMap<String, String> pmap = new HashMap<String, String>();

		if (column != null && word != null) {
			isSearch = true;
			pmap.put("column", column);
			pmap.put("word", word);

		}
		// 페이지바~
		pmap.put("start", start + "");
		pmap.put("end", end + "");

		List<BoardproductDTO> plist = null; // 목록리스트

		plist = dao.plist(pmap);
		plist = dao.plist(pmap);

		// 데이터 검색
		for (int i = 0; i < plist.size(); i++) {
			BoardproductDTO dto = plist.get(i); // 글 1개

			// 자르기 전의 시각으로 구분지어야한다***
			// 최신글 표시 -> 1일, 12시간, 7일 등..
			// 현재 시간 - 글쓴 시간 -> tick값 연산
			// Date datoe = Calendar.getTime();
			// long tick = date.getTime(); -> 시각을 ms로 계산한 값

			// 현재시간
			Calendar now = Calendar.getInstance();
			long nowTick = now.getTime().getTime();

			// 글쓴시간(문자열 -> 날짜 시간형)
			SimpleDateFormat format = new SimpleDateFormat(
					"yyyy-MM-dd HH:mm:ss"); // Oracle

			try {
				// java.util.Date
				Date regdate = format.parse(dto.getRegDate());

				long regdateTick = regdate.getTime();

				// 글쓴 뒤 지나간 시간??
				long span = nowTick - regdateTick; // 시간 = 시각 - 시각

				if ((span / 1000 / 60 / 60) < 24) { // 글쓴지 하루가 안 지났습니까?
					// System.out.println("새글");
					dto.setIsNew("<img src='/spring/images/new.png' />");
				}

			} catch (Exception e) {
				System.out.println(e.toString());
			}

			// 날짜 처리
			String temp = dto.getRegDate().substring(0, 10);
			dto.setRegDate(temp);

			// 제목이 길면.. 자르기
			String title = dto.getTitle();

			if (title.length() > 25)
				title = title.substring(0, 24) + "...";

			dto.setTitle(title);

			// 제목이 검색중이면.. 검색어 부각
			if (isSearch && column.equals("title")) {
				title = dto.getTitle();

				// 이글은 테스트 입니다.

				// 이글은 <span style='background-color:yellow;color:red;'>
				// 테스트</span> 입니다.

				title = title.replace(word,
						"<span style='background-color:yellow;color:red;'>"
								+ word + "</span>");
				dto.setTitle(title);
			}
		}// for ***

		// 페이징
		// 총 페이지 수 ?
		totalCount = dao.getpTotalCount(); // 124
		totalPage = (int) Math.ceil((double) totalCount / pageSize); // 무조건
		// 올림(3.1->4)

		// 페이비바 생성
		String pagebar = "";

		pagebar += "<nav id='nav1'><ul class='pagination'>";

		/*
		 * for (int i=1; i< totalPage; i++) { pagebar +=
		 * String.format("<li><a href='#'>%d</a></li>",i); }
		 */
		// blockSize : 한번에 보여질 페이지 최대 갯수

		// 페이지 번호를 만들기 위한 루프 변수
		loop = 1;
		// 페이지 출력 번호 변수(페이지 번호)
		// 5페이지 ->1
		// 8페이지 ->1
		// 10 페이지 -> 1
		// 11~20페이지는 -> 11
		n = ((nowpage - 1) / blockSize) * blockSize + 1;

		// 이전 10페이지
		if (n == 1) {
			pagebar += String
					.format("<li class='disabled'><a href='#' aria-label='Previous'><span aria-hidden='true'>&laquo;</span></a></li>",
							n - 1);
		} else {
			pagebar += String
					.format("<li><a href='/spring/board/productlist.hush?page=%d' aria-label='Previous'><span aria-hidden='true'>&laquo;</span></a></li>",
							n - 1);
		}
		while (!(loop > blockSize || n > totalPage)) {

			if (n == nowpage) {
				pagebar += String.format(
						"<li class='active'><a href='#'>%d</a></li>", n);

			} else {
				pagebar += String
						.format("<li><a href='/spring/board/productlist.hush?page=%d'>%d</a></li>",
								n, n);

			}
			loop++;
			n++;
		}

		// 다음 10페이지

		if (n > totalPage) {
			pagebar += String
					.format("<li class='disabled'><a href='#' aria-label='Next'><span aria-hidden='true'>&raquo;</span></a></li>",
							n);
		} else {
			pagebar += String
					.format("<li><a href='/spring/board/productlist.hush?page=%d' aria-label='Next'><span aria-hidden='true'>&raquo;</span></a></li>",
							n);
		}
		pagebar += "</ul></nav>";

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		
		req.setAttribute("plist", plist);
		req.setAttribute("pmap", pmap);
		req.setAttribute("pagebar", pagebar);
		return "board/productlist";
	}

	// 상품 Q&A 댓글 쓰기
	@RequestMapping(value = "/board/productcomment.hush", method = { RequestMethod.POST })
	public String productComment(HttpServletRequest req,
			BoardproductCommentDTO dto, HttpSession session) {

		// 1. 데이터 가져오기 (name, content, bseq)
		// 2. DAO 위임(insert)
		// 3. 결과값 -> JSP 호출

		int result = dao.productComment(dto);

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		
		req.setAttribute("result", result);
		req.setAttribute("seq", dto.getAccommodationQuestionSeq());

		return "board/productComment";
	}

	// 상품 Q&A 글쓰기
	@RequestMapping(value = "/board/productadd.hush", method = { RequestMethod.GET })
	public String padd(HttpServletRequest req, HttpSession session) {
		
		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		return "board/productadd";
	}

	// 상품 Q&A 글쓰기 완료
	@RequestMapping(value = "/board/productaddok.hush", method = { RequestMethod.POST })
	public String paddok(HttpServletRequest req, BoardproductDTO dto, HttpSession session) { // 1.

		// 1. 데이터 가져오기(DTO) - 전처리
		// 2. DAO 위임(insert)
		// 3. 완료 메시지 -> JSP 호출(위임)

		// 2.
		int result = dao.padd(dto); // 글쓰기

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		
		req.setAttribute("result", result);

		return "board/productaddok";
	}

	// 상품 Q&A 글 보기
	@RequestMapping(value = "/board/productview.hush", method = { RequestMethod.GET })
	public String pview(HttpServletRequest req, String seq, HttpSession session) {

		// 1. 데이터 가져오기(view.action?seq=1)
		// 2. DAO위임(select)
		// 3. 결과값 DTO 반환 -> JSP 호출

		// 조회수 처리
		// HttpSession session = req.getSession(); -> 파라미터로 받는거랑 같아
		session.setAttribute("read", "n");

		// 새로고침으로 인한 조회수 증가 막기***********
		if (session.getAttribute("read") != null) { // list를 통해 들어온 경우에만
			if (session.getAttribute("read").toString().equals("n")) {
				// 조회수 증가(update)
				dao.productCount(seq); // 글번호 넘겨줘
				session.setAttribute("read", "y");
			}
		}

		// 2.
		BoardproductDTO dto = dao.pview(seq);

		// 숙박에대한 정보를 가져오는거에요

		AccommodationDTO a_dto = dao.aview(dto.getCodenum());

		// 일반적으로 태그작성 자체를 막아
		// 자바스크립트도 다 건드릴수 있자나 망해*********

		// <script>방지
		dto.setContent(dto.getContent().replace("<script", "&lt;script")
				.replace("</script>", "&lt;/script&gt;"));

		// 글내용의 엔터값 처리 -> 순서2***
		dto.setContent(dto.getContent().replace("\n", "<br />"));

		// 시간 조작 -> 뒤에 0 제거
		dto.setRegDate(dto.getRegDate().substring(0, 19));

		// 현재 보고 있는 글의 달린 댓글 가져오기
		// seq -> bseq
		List<BoardproductCommentDTO> pclist = dao.pclist(seq);

		System.out.println(a_dto.getMainImg());

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		
		req.setAttribute("a_dto", a_dto); // 숙박정보에서 코드넘 넘기기
		req.setAttribute("pclist", pclist);
		req.setAttribute("dto", dto);
		return "board/productview";
	}

	// 여기까지~!! 상품 Q&A 유저버전~!!!
	// -----------------------------------------------------------------------------------
	// 홈페이지 Q&A 시작~!

	@RequestMapping(value = "/board/homepagelist.hush", method = { RequestMethod.GET })
	public String hlist(HttpServletRequest req, HttpSession session) {

		// 홈페이지 페이징
		// - homepagelist.hush -> noticelist.hush?page=1
		// - homepagelist.hush?page=5

		int nowpage = 0; // 현재 페이지 번호 (잠시저장)
		int totalCount = 0; // 총 게시물 수
		int totalPage = 0; // 총 페이지 수
		int pageSize = 10; // 한페이지당 게시물 수
		int n = 0, loop = 0;
		int start = 0, end = 0;
		int blockSize = 10;

		String page = req.getParameter("page");

		if (page == null) {
			nowpage = 1;
		} else {

			nowpage = Integer.parseInt(page);
		}

		// nowpage-> 지금 출력 페이지 번호

		// 가져올 게시물의 범위 결정

		start = ((nowpage - 1) * pageSize) + 1;
		end = start + pageSize - 1;

		// 1. 목록보기(list.action)
		// 2. 검색하기(list.action?column=name&word=홍길동)

		boolean isSearch = false;

		String column = req.getParameter("column");
		String word = req.getParameter("word");
		HashMap<String, String> hmap = new HashMap<String, String>();

		if (column != null && word != null) {
			isSearch = true;
			hmap.put("column", column);
			hmap.put("word", word);

		}
		// 페이지바~
		hmap.put("start", start + "");
		hmap.put("end", end + "");

		List<BoardhomepageDTO> hlist = null; // 목록리스트

		hlist = dao.hlist(hmap);
		hlist = dao.hlist(hmap);

		// 데이터 검색
		for (int i = 0; i < hlist.size(); i++) {
			BoardhomepageDTO dto = hlist.get(i); // 글 1개

			// 자르기 전의 시각으로 구분지어야한다***
			// 최신글 표시 -> 1일, 12시간, 7일 등..
			// 현재 시간 - 글쓴 시간 -> tick값 연산
			// Date datoe = Calendar.getTime();
			// long tick = date.getTime(); -> 시각을 ms로 계산한 값

			// 현재시간
			Calendar now = Calendar.getInstance();
			long nowTick = now.getTime().getTime();

			// 글쓴시간(문자열 -> 날짜 시간형)
			SimpleDateFormat format = new SimpleDateFormat(
					"yyyy-MM-dd HH:mm:ss"); // Oracle

			try {
				// java.util.Date
				Date regdate = format.parse(dto.getRegDate());

				long regdateTick = regdate.getTime();

				// 글쓴 뒤 지나간 시간??
				long span = nowTick - regdateTick; // 시간 = 시각 - 시각

				if ((span / 1000 / 60 / 60) < 24) { // 글쓴지 하루가 안 지났습니까?
					// System.out.println("새글");
					dto.setIsNew("<img src='/spring/images/new.png' />");
				}

			} catch (Exception e) {
				System.out.println(e.toString());
			}

			// 날짜 처리
			String temp = dto.getRegDate().substring(0, 10);
			dto.setRegDate(temp);

			// 제목이 길면.. 자르기
			String title = dto.getTitle();

			if (title.length() > 25)
				title = title.substring(0, 24) + "...";

			dto.setTitle(title);

			// 제목이 검색중이면.. 검색어 부각
			if (isSearch && column.equals("title")) {
				title = dto.getTitle();

				// 이글은 테스트 입니다.

				// 이글은 <span style='background-color:yellow;color:red;'>
				// 테스트</span> 입니다.

				title = title.replace(word,
						"<span style='background-color:yellow;color:red;'>"
								+ word + "</span>");
				dto.setTitle(title);
			}
		}// for ***

		// 페이징
		// 총 페이지 수 ?
		totalCount = dao.gethTotalCount(); // 124
		totalPage = (int) Math.ceil((double) totalCount / pageSize); // 무조건
		// 올림(3.1->4)

		// 페이비바 생성
		String pagebar = "";

		pagebar += "<nav id='nav1'><ul class='pagination'>";

		/*
		 * for (int i=1; i< totalPage; i++) { pagebar +=
		 * String.format("<li><a href='#'>%d</a></li>",i); }
		 */
		// blockSize : 한번에 보여질 페이지 최대 갯수

		// 페이지 번호를 만들기 위한 루프 변수
		loop = 1;
		// 페이지 출력 번호 변수(페이지 번호)
		// 5페이지 ->1
		// 8페이지 ->1
		// 10 페이지 -> 1
		// 11~20페이지는 -> 11
		n = ((nowpage - 1) / blockSize) * blockSize + 1;

		// 이전 10페이지
		if (n == 1) {
			pagebar += String
					.format("<li class='disabled'><a href='#' aria-label='Previous'><span aria-hidden='true'>&laquo;</span></a></li>",
							n - 1);
		} else {
			pagebar += String
					.format("<li><a href='/spring/board/homepagelist.hush?page=%d' aria-label='Previous'><span aria-hidden='true'>&laquo;</span></a></li>",
							n - 1);
		}
		while (!(loop > blockSize || n > totalPage)) {

			if (n == nowpage) {
				pagebar += String.format(
						"<li class='active'><a href='#'>%d</a></li>", n);

			} else {
				pagebar += String
						.format("<li><a href='/spring/board/homepagelist.hush?page=%d'>%d</a></li>",
								n, n);

			}
			loop++;
			n++;
		}

		// 다음 10페이지

		if (n > totalPage) {
			pagebar += String
					.format("<li class='disabled'><a href='#' aria-label='Next'><span aria-hidden='true'>&raquo;</span></a></li>",
							n);
		} else {
			pagebar += String
					.format("<li><a href='/spring/board/homepagelist.hush?page=%d' aria-label='Next'><span aria-hidden='true'>&raquo;</span></a></li>",
							n);
		}
		pagebar += "</ul></nav>";

		// 아이디 넘겨주기
		String id = (String) session.getAttribute("id");
		req.setAttribute("id", id);

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		
		req.setAttribute("hlist", hlist);
		req.setAttribute("hmap", hmap);
		req.setAttribute("pagebar", pagebar);
		return "board/homepagelist";
	}

	// 홈페이지 Q&A 댓글 쓰기
	@RequestMapping(value = "/board/homepagecomment.hush", method = { RequestMethod.POST })
	public String homepageComment(HttpServletRequest req,
			BoardhomepageCommentDTO dto, HttpSession session) {

		// 1. 데이터 가져오기 (name, content, bseq)
		// 2. DAO 위임(insert)
		// 3. 결과값 -> JSP 호출

		int result = dao.homepageComment(dto);
		
		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		req.setAttribute("result", result);
		req.setAttribute("seq", dto.getHomepageQuestionSeq());

		return "board/homepageComment";
	}

	// 홈페이지 글쓰기
	@RequestMapping(value = "/board/homepageadd.hush", method = { RequestMethod.GET })
	public String hadd(HttpServletRequest req, HttpSession session) {

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		
		return "board/homepageadd";
	}

	// 홈페이지 글쓰기 완료
	@RequestMapping(value = "/board/homepageaddok.hush", method = { RequestMethod.POST })
	public String haddok(HttpServletRequest req, BoardhomepageDTO dto, HttpSession session) { // 1.

		// 1. 데이터 가져오기(DTO) - 전처리
		// 2. DAO 위임(insert)
		// 3. 완료 메시지 -> JSP 호출(위임)

		// 2.
		int result = dao.hadd(dto); // 글쓰기

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		
		req.setAttribute("result", result);

		return "board/homepageaddok";
	}

	// 홈페이지 글 보기
	@RequestMapping(value = "/board/homepageview.hush", method = { RequestMethod.GET })
	public String hview(HttpServletRequest req, String seq, HttpSession session) {

		// 1. 데이터 가져오기(view.action?seq=1)
		// 2. DAO위임(select)
		// 3. 결과값 DTO 반환 -> JSP 호출

		// 조회수 처리
		// HttpSession session = req.getSession(); -> 파라미터로 받는거랑 같아
		session.setAttribute("read", "n");

		// 새로고침으로 인한 조회수 증가 막기***********
		if (session.getAttribute("read") != null) { // list를 통해 들어온 경우에만
			if (session.getAttribute("read").toString().equals("n")) {
				// 조회수 증가(update)
				dao.homepageCount(seq); // 글번호 넘겨줘
				session.setAttribute("read", "y");
			}
		}

		// 2.
		BoardhomepageDTO dto = dao.hview(seq);

		// 일반적으로 태그작성 자체를 막아
		// 자바스크립트도 다 건드릴수 있자나 망해*********

		// <script>방지
		dto.setContent(dto.getContent().replace("<script", "&lt;script")
				.replace("</script>", "&lt;/script&gt;"));

		// 글내용의 엔터값 처리 -> 순서2***
		dto.setContent(dto.getContent().replace("\n", "<br />"));

		// 시간 조작 -> 뒤에 0 제거
		dto.setRegDate(dto.getRegDate().substring(0, 19));
		// 현재 보고 있는 글의 달린 댓글 가져오기
		// seq -> bseq
		List<BoardhomepageCommentDTO> hclist = dao.hclist(seq);

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		
		req.setAttribute("hclist", hclist);

		req.setAttribute("dto", dto);
		return "board/homepageview";
	}

	// -----------------------------여기까지 홈페이지 Q&A ------------------------------

	// ---------------------------리뷰 시작~----------------------------------

	@RequestMapping(value = "/board/reviewlist.hush", method = { RequestMethod.GET })
	public String rlist(HttpServletRequest req, HttpSession session) {

		// 리뷰 페이징
		// - reviewlist.hush -> reviewlist.hush?page=1
		// - reviewlist.hush?page=5

		int nowpage = 0; // 현재 페이지 번호 (잠시저장)
		int totalCount = 0; // 총 게시물 수
		int totalPage = 0; // 총 페이지 수
		int pageSize = 10; // 한페이지당 게시물 수
		int n = 0, loop = 0;
		int start = 0, end = 0;
		int blockSize = 10;

		String page = req.getParameter("page");

		if (page == null) {
			nowpage = 1;
		} else {

			nowpage = Integer.parseInt(page);
		}

		// nowpage-> 지금 출력 페이지 번호

		// 가져올 게시물의 범위 결정

		start = ((nowpage - 1) * pageSize) + 1;
		end = start + pageSize - 1;

		// 1. 목록보기(review.hush)
		// 2. 검색하기(review.hush?column=name&word=홍길동)

		boolean isSearch = false;

		String column = req.getParameter("column");
		String word = req.getParameter("word");
		HashMap<String, String> rmap = new HashMap<String, String>();

		if (column != null && word != null) {
			isSearch = true;
			rmap.put("column", column);
			rmap.put("word", word);

		}
		// 페이지바~
		rmap.put("start", start + "");
		rmap.put("end", end + "");

		List<BoardreviewDTO> rlist = null; // 목록리스트

		rlist = dao.rlist(rmap);
		rlist = dao.rlist(rmap);

		// 데이터 검색
		for (int i = 0; i < rlist.size(); i++) {
			BoardreviewDTO dto = rlist.get(i); // 글 1개

			// 자르기 전의 시각으로 구분지어야한다***
			// 최신글 표시 -> 1일, 12시간, 7일 등..
			// 현재 시간 - 글쓴 시간 -> tick값 연산
			// Date datoe = Calendar.getTime();
			// long tick = date.getTime(); -> 시각을 ms로 계산한 값

			// 현재시간
			Calendar now = Calendar.getInstance();
			long nowTick = now.getTime().getTime();

			// 글쓴시간(문자열 -> 날짜 시간형)
			SimpleDateFormat format = new SimpleDateFormat(
					"yyyy-MM-dd HH:mm:ss"); // Oracle

			try {
				// java.util.Date
				Date regdate = format.parse(dto.getRegDate());

				long regdateTick = regdate.getTime();

				// 글쓴 뒤 지나간 시간??
				long span = nowTick - regdateTick; // 시간 = 시각 - 시각

				if ((span / 1000 / 60 / 60) < 24) { // 글쓴지 하루가 안 지났습니까?
					// System.out.println("새글");
					dto.setIsNew("<img src='/spring/images/new.png' />");
				}

			} catch (Exception e) {
				System.out.println(e.toString());
			}

			// 날짜 처리
			String temp = dto.getRegDate().substring(0, 10);
			dto.setRegDate(temp);

			// 제목이 길면.. 자르기
			String title = dto.getTitle();

			if (title.length() > 25)
				title = title.substring(0, 24) + "...";

			dto.setTitle(title);

			// 제목이 검색중이면.. 검색어 부각
			if (isSearch && column.equals("title")) {
				title = dto.getTitle();

				// 이글은 테스트 입니다.

				// 이글은 <span style='background-color:yellow;color:red;'>
				// 테스트</span> 입니다.

				title = title.replace(word,
						"<span style='background-color:yellow;color:red;'>"
								+ word + "</span>");
				dto.setTitle(title);
			}
		}// for ***

		// 페이징
		// 총 페이지 수 ?
		totalCount = dao.getrTotalCount(); // 124
		totalPage = (int) Math.ceil((double) totalCount / pageSize); // 무조건
		// 올림(3.1->4)

		// 페이비바 생성
		String pagebar = "";

		pagebar += "<nav id='nav1'><ul class='pagination'>";

		/*
		 * for (int i=1; i< totalPage; i++) { pagebar +=
		 * String.format("<li><a href='#'>%d</a></li>",i); }
		 */
		// blockSize : 한번에 보여질 페이지 최대 갯수

		// 페이지 번호를 만들기 위한 루프 변수
		loop = 1;
		// 페이지 출력 번호 변수(페이지 번호)
		// 5페이지 ->1
		// 8페이지 ->1
		// 10 페이지 -> 1
		// 11~20페이지는 -> 11
		n = ((nowpage - 1) / blockSize) * blockSize + 1;

		// 이전 10페이지
		if (n == 1) {
			pagebar += String
					.format("<li class='disabled'><a href='#' aria-label='Previous'><span aria-hidden='true'>&laquo;</span></a></li>",
							n - 1);
		} else {
			pagebar += String
					.format("<li><a href='/spring/board/reviewlist.hush?page=%d' aria-label='Previous'><span aria-hidden='true'>&laquo;</span></a></li>",
							n - 1);
		}
		while (!(loop > blockSize || n > totalPage)) {

			if (n == nowpage) {
				pagebar += String.format(
						"<li class='active'><a href='#'>%d</a></li>", n);

			} else {
				pagebar += String
						.format("<li><a href='/spring/board/reviewlist.hush?page=%d'>%d</a></li>",
								n, n);

			}
			loop++;
			n++;
		}

		// 다음 10페이지

		if (n > totalPage) {
			pagebar += String
					.format("<li class='disabled'><a href='#' aria-label='Next'><span aria-hidden='true'>&raquo;</span></a></li>",
							n);
		} else {
			pagebar += String
					.format("<li><a href='/spring/board/reviewlist.hush?page=%d' aria-label='Next'><span aria-hidden='true'>&raquo;</span></a></li>",
							n);
		}
		pagebar += "</ul></nav>";

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		
		req.setAttribute("rlist", rlist);
		req.setAttribute("rmap", rmap);
		req.setAttribute("pagebar", pagebar);
		return "board/reviewlist";
	}

	// 리뷰 글 상세보기
	@RequestMapping(value = "/board/reviewview.hush", method = { RequestMethod.GET })
	public String rview(HttpServletRequest req, String seq, HttpSession session) {

		// 1. 데이터 가져오기(view.action?seq=1)
		// 2. DAO위임(select)
		// 3. 결과값 DTO 반환 -> JSP 호출

		// 조회수 처리
		// HttpSession session = req.getSession(); -> 파라미터로 받는거랑 같아
		session.setAttribute("read", "n");

		// 새로고침으로 인한 조회수 증가 막기***********
		if (session.getAttribute("read") != null) { // list를 통해 들어온 경우에만
			if (session.getAttribute("read").toString().equals("n")) {
				// 조회수 증가(update)
				dao.reviewCount(seq); // 글번호 넘겨줘
				session.setAttribute("read", "y");
			}
		}

		// 2.
		BoardreviewDTO dto = dao.rview(seq);

		// 일반적으로 태그작성 자체를 막아
		// 자바스크립트도 다 건드릴수 있자나 망해*********

		// <script>방지
		dto.setContent(dto.getContent().replace("<script", "&lt;script")
				.replace("</script>", "&lt;/script&gt;"));

		// 글내용의 엔터값 처리 -> 순서2***
		dto.setContent(dto.getContent().replace("\n", "<br />"));

		// 시간 조작 -> 뒤에 0 제거
		dto.setRegDate(dto.getRegDate().substring(0, 19));

		AccommodationDTO a_dto = dao.arview(dto.getCodeNum());

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		
		req.setAttribute("a_dto", a_dto); // 숙박정보에서 코드넘 넘기기

		req.setAttribute("dto", dto);
		return "board/reviewview";
	}

}