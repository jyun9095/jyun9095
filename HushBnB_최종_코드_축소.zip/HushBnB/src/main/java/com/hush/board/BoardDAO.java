package com.hush.board;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hush.board.BoardDTO;
import com.hush.board.BoardproductCommentDTO;
import com.hush.board.BoardhomepageCommentDTO;
import com.hush.main.AccommodationDTO;

@Repository
public class BoardDAO {

   @Autowired
   private SqlSessionTemplate sql;

   // 공지사항 글쓰기
   public int nadd(BoardDTO dto) {
      System.out.println(dto.getContent());
      System.out.println(dto.getTitle());
      int result = 0;

      result = sql.insert("board.nadd", dto);

      return result;
   }

   // 공지사항 글 목록 보기
   public List<BoardDTO> nlist() {
      // List는 인터페이스라 생성자로 작성x
      List<BoardDTO> nlist = new ArrayList<BoardDTO>();

      nlist = sql.selectList("board.nlist");

      return nlist;

   }

   // 공지사항 검색하기
   public List<BoardDTO> nlist(HashMap<String, String> nmap) {

      // List는 인터페이스라 생성자로 작성x
      List<BoardDTO> nlist = new ArrayList<BoardDTO>();

      nlist = sql.selectList("board.nlist", nmap);

      return nlist;
   }

   // 공지사항 상세보기
   public BoardDTO nview(String seq) {

      BoardDTO dto = sql.selectOne("board.nview", seq);

      return dto;
   }

   // 공지사항 조회수
   public void noticeCount(String seq) {
      sql.update("board.noticeCount", seq);

   }

   // 공지사항 페이지바
   public int getTotalCount() {

      return sql.selectOne("board.totalCount");
   }

   // 공지사항 글수정
   public int nedit(BoardDTO dto) {

      int result = 0;

      result = sql.update("board.nedit", dto);

      return result;
   }

   // 공지사항 글 삭제
   public int ndel(String seq) {

      int result = 0;
      result = sql.delete("board.noticedel", seq);

      return result;
   }

   
   // -----------------------------------여기부터상품Q&A----------------------------------------------

   // 상품Q&A 글 목록 보기
   public List<BoardproductDTO> plist() {
      // List는 인터페이스라 생성자로 작성x
      List<BoardproductDTO> plist = new ArrayList<BoardproductDTO>();

      plist = sql.selectList("board.nlist");

      return plist;

   }

   // 상품Q&A 검색하기
   public List<BoardproductDTO> plist(HashMap<String, String> pmap) {

      // List는 인터페이스라 생성자로 작성x
      List<BoardproductDTO> plist = new ArrayList<BoardproductDTO>();

      plist = sql.selectList("board.plist", pmap);

      return plist;
   }

   // 상품 Q&A 글쓰기
   public int padd(BoardproductDTO dto) {
      System.out.println(dto.getContent());
      System.out.println(dto.getTitle());
      int result = 0;

      result = sql.insert("board.padd", dto);

      return result;

   }

   // 상품 Q&A 글 상세보기
   public BoardproductDTO pview(String seq) {

      BoardproductDTO dto = sql.selectOne("board.pview", seq);

      return dto;
   }

   // 상품 Q&A 조회수 증가
   public void productCount(String seq) {
      sql.update("board.productCount", seq);

   }

   public int getpTotalCount() {

      return sql.selectOne("board.ptotalCount");

   }

   // 상품 Q&A 댓글쓰기
   public int productComment(BoardproductCommentDTO dto) {

      int result = 0;

      result = sql.insert("board.productComment", dto);

      return result;
   }

   // 상품 Q&A 댓글 가져오기
   public List<BoardproductCommentDTO> pclist(String seq) {

      return sql.selectList("board.pclist", seq);

   }
   //상품 Q&A  상품정보에서 codenum 넘기는것
   public AccommodationDTO aview(String codenum) {
      
      return sql.selectOne("board.aview", codenum);
   }

   // ------------------------------여기까지 상품 Q&A--------------------

   // 홈페이지 글쓰기
   public int hadd(BoardhomepageDTO dto) {
      System.out.println(dto.getContent());
      System.out.println(dto.getTitle());
      int result = 0;

      result = sql.insert("board.hadd", dto);

      return result;
   }

   // 홈페이지 글 목록 보기
   public List<BoardhomepageDTO> hlist() {
      // List는 인터페이스라 생성자로 작성x
      List<BoardhomepageDTO> hlist = new ArrayList<BoardhomepageDTO>();

      hlist = sql.selectList("board.hlist");

      return hlist;

   }

   // 홈페이지 검색하기
   public List<BoardhomepageDTO> hlist(HashMap<String, String> hmap) {

      // List는 인터페이스라 생성자로 작성x
      List<BoardhomepageDTO> hlist = new ArrayList<BoardhomepageDTO>();

      hlist = sql.selectList("board.hlist", hmap);

      return hlist;
   }

   // 홈페이지 상세보기
   public BoardhomepageDTO hview(String seq) {

      BoardhomepageDTO dto = sql.selectOne("board.hview", seq);

      return dto;
   }

   // 홈페이지 조회수
   public void homepageCount(String seq) {
      sql.update("board.homepageCount", seq);

   }

   // 홈페이지 페이지바
   public int gethTotalCount() {

      return sql.selectOne("board.htotalCount");
   }

   // 홈페이지 Q&A 댓글쓰기
   public int homepageComment(BoardhomepageCommentDTO dto) {

      int result = 0;

      result = sql.insert("board.homepageComment", dto);

      return result;
   }

   // 홈페이지 Q&A 댓글 가져오기
   public List<BoardhomepageCommentDTO> hclist(String seq) {

      return sql.selectList("board.hclist", seq);

   }

   // ------------------------리뷰-------------------------------

   // 리뷰 글 목록 보기
   public List<BoardreviewDTO> rlist() {
      // List는 인터페이스라 생성자로 작성x
      List<BoardreviewDTO> rlist = new ArrayList<BoardreviewDTO>();

      rlist = sql.selectList("board.rlist");

      return rlist;

   }

   // 리뷰 검색하기
   public List<BoardreviewDTO> rlist(HashMap<String, String> rmap) {

      // List는 인터페이스라 생성자로 작성x
      List<BoardreviewDTO> rlist = new ArrayList<BoardreviewDTO>();

      rlist = sql.selectList("board.rlist", rmap);

      return rlist;
   }

   // 리뷰 상세보기
   public BoardreviewDTO rview(String seq) {

      BoardreviewDTO dto = sql.selectOne("board.rview", seq);

      return dto;
   }

   // 리뷰 조회수
   public void reviewCount(String seq) {
      sql.update("board.reviewCount", seq);

   }

   // 리뷰 페이지바
   public int getrTotalCount() {

      return sql.selectOne("board.rtotalCount");
   }
   // 리뷰 코드넘을 통한 숙박정보 가져오기
public AccommodationDTO arview(String codeNum) {
   
   return sql.selectOne("board.aview", codeNum);
}



}