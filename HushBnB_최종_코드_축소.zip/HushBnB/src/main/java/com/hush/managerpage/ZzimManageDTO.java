package com.hush.managerpage;

public class ZzimManageDTO {

	private String seq;
	private String name;
	private String accommodationCodeNum;
	private String dDay;
	private String address;
	private String price;
	private String id; 
	
	//DB외의 데이터
	private String cnt;
	private String ids; //-> 세명의 아이디
	private String nowDay;
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAccommodationCodeNum() {
		return accommodationCodeNum;
	}
	public void setAccommodationCodeNum(String accommodationCodeNum) {
		this.accommodationCodeNum = accommodationCodeNum;
	}
	public String getdDay() {
		return dDay;
	}
	public void setdDay(String dDay) {
		this.dDay = dDay;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCnt() {
		return cnt;
	}
	public void setCnt(String cnt) {
		this.cnt = cnt;
	}
	public String getIds() {
		return ids;
	}
	public void setIds(String ids) {
		this.ids = ids;
	}
	public String getNowDay() {
		return nowDay;
	}
	public void setNowDay(String nowDay) {
		this.nowDay = nowDay;
	}
	
	
	
	
}
