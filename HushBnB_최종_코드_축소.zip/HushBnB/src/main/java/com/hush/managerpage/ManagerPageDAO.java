package com.hush.managerpage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ManagerPageDAO {

	@Autowired
	private SqlSessionTemplate sql;

	public List<MemberManageDTO> list() {

		List<MemberManageDTO> list = new ArrayList<MemberManageDTO>();

		list = sql.selectList("managerpage.list");

		return list;

	}

	public List<Integer> analysis() {

		List<Integer> analysis = new ArrayList<Integer>();

		analysis = sql.selectList("managerpage.analysis");

		return analysis;

	}

	public List<Integer> analysisage() {

		List<Integer> analysisage = new ArrayList<Integer>();

		analysisage = sql.selectList("managerpage.analysisage");

		return analysisage;
	}

	public List<CityDTO> cityList() {

		List<CityDTO> list = new ArrayList<CityDTO>();

		list = sql.selectList("managerpage.cityname");

		return list;
	}

	public List<RegionDTO> regionList(int citySeq) {

		return sql.selectList("managerpage.regionname", citySeq);
	}

	public List<AccommodationDTO> getAccommodation(String regionSeq) {

		return sql.selectList("managerpage.accommodationListRegion", regionSeq);
	}

	public List<AccommodationDTO> getAccommodation() {

		return sql.selectList("managerpage.accommodationList");

	}

	public int accomsave(ImgDTO dto) {

		int accomsave = 0;

		accomsave = sql.insert("managerpage.accomsave", dto);

		return accomsave;

	}

	public int accomsave1(ImgDTO dto) {

		int accomsave1 = 0;

		accomsave1 = sql.insert("managerpage.accomsave1", dto);

		return accomsave1;

	}

	public int accomsave2(ImgDTO dto) {

		int accomsave2 = 0;

		accomsave2 = sql.insert("managerpage.accomsave2", dto);

		return accomsave2;

	}

	public List<ZzimManageDTO> zzimManage(String nowDay) {

		return sql.selectList("managerpage.zzimManage", nowDay);
	}

	public List<ZzimManageDTO> successZzim(HashMap<String, String> map) {

		return sql.selectList("managerpage.successZzim", map);
	}


	public int zzimMessage(ZzimManageDTO dto) {

		return sql.insert("managerpage.zzimMessage", dto);
	}

	public int checkMessage(ZzimManageDTO dto) {
		
		return sql.selectOne("managerpage.checkMessage", dto);
	}

}