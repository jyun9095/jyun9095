package com.hush.managerpage;

public class CityDTO {

   private String seq;
   private String city;
   
   public String getSeq() {
      return seq;
   }
   public void setSeq(String seq) {
      this.seq = seq;
   }
   public String getCity() {
      return city;
   }
   public void setCity(String city) {
      this.city = city;
   }
   
}