package com.hush.managerpage;

import org.springframework.web.multipart.MultipartFile;

public class ImgDTO {

   private String codeNum;
   private String regionSeq;
   private String name;
   private String address;
   private String mainImg;
   private String fileName;
   private String checkIn;
   private String checkOut;
   private String price;
   private String breakFirst;
   private String totalZzim;
   private String bathroom;
   private String bed;
   private String room;
   private String gender;
   
   private String seq;
   private String internet;
   private String elevator;
   private String tv;
   private String washingMachine;
   private String hairDryer;
   private String pool;
   private String parkingLot;
   
   private String detailImg1;
   private String fileName1;
   private String detailImg2;
   private String fileName2;
   private String detailImg3;
   private String fileName3;
   private String detailImg4;
   private String fileName4;
   private String detailImg5;
   private String fileName5;
   
   private MultipartFile attch;
   private MultipartFile attch1;
   private MultipartFile attch2;
   private MultipartFile attch3;
   private MultipartFile attch4;
   private MultipartFile attch5;
   
   public MultipartFile getAttch() {
      return attch;
   }
   public void setAttch(MultipartFile attch) {
      this.attch = attch;
   }   
   public String getElevator() {
      return elevator;
   }
   public void setElevator(String elevator) {
      this.elevator = elevator;
   }
   public String getTv() {
      return tv;
   }
   public void setTv(String tv) {
      this.tv = tv;
   }
   public String getWashingMachine() {
      return washingMachine;
   }
   public void setWashingMachine(String washingMachine) {
      this.washingMachine = washingMachine;
   }
   public String getHairDryer() {
      return hairDryer;
   }
   public void setHairDryer(String hairDryer) {
      this.hairDryer = hairDryer;
   }
   public String getPool() {
      return pool;
   }
   public void setPool(String pool) {
      this.pool = pool;
   }
   public String getParkingLot() {
      return parkingLot;
   }
   public void setParkingLot(String parkingLot) {
      this.parkingLot = parkingLot;
   }
   
   public String getCodeNum() {
      return codeNum;
   }
   public void setCodeNum(String codeNum) {
      this.codeNum = codeNum;
   }
   public String getRegionSeq() {
      return regionSeq;
   }
   public void setRegionSeq(String regionSeq) {
      this.regionSeq = regionSeq;
   }
   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }
   public String getAddress() {
      return address;
   }
   public void setAddress(String address) {
      this.address = address;
   }
   public String getMainImg() {
      return mainImg;
   }
   public void setMainImg(String mainImg) {
      this.mainImg = mainImg;
   }
   public String getFileName() {
      return fileName;
   }
   public void setFileName(String fileName) {
      this.fileName = fileName;
   }
   public String getCheckIn() {
      return checkIn;
   }
   public void setCheckIn(String checkIn) {
      this.checkIn = checkIn;
   }
   public String getCheckOut() {
      return checkOut;
   }
   public void setCheckOut(String checkOut) {
      this.checkOut = checkOut;
   }
   public String getPrice() {
      return price;
   }
   public void setPrice(String price) {
      this.price = price;
   }
   public String getBreakFirst() {
      return breakFirst;
   }
   public void setBreakFirst(String breakFirst) {
      this.breakFirst = breakFirst;
   }
   public String getTotalZzim() {
      return totalZzim;
   }
   public void setTotalZzim(String totalZzim) {
      this.totalZzim = totalZzim;
   }
   public String getBathroom() {
      return bathroom;
   }
   public void setBathroom(String bathroom) {
      this.bathroom = bathroom;
   }
   public String getBed() {
      return bed;
   }
   public void setBed(String bed) {
      this.bed = bed;
   }
   public String getRoom() {
      return room;
   }
   public void setRoom(String room) {
      this.room = room;
   }
   public String getGender() {
      return gender;
   }
   public void setGender(String gender) {
      this.gender = gender;
   }
   public String getSeq() {
      return seq;
   }
   public void setSeq(String seq) {
      this.seq = seq;
   }
   
   public String getFileName1() {
      return fileName1;
   }
   public void setFileName1(String fileName1) {
      this.fileName1 = fileName1;
   }
   
   public String getFileName2() {
      return fileName2;
   }
   public void setFileName2(String fileName2) {
      this.fileName2 = fileName2;
   }
   
   public String getFileName3() {
      return fileName3;
   }
   public void setFileName3(String fileName3) {
      this.fileName3 = fileName3;
   }
   
   public String getFileName4() {
      return fileName4;
   }
   public void setFileName4(String fileName4) {
      this.fileName4 = fileName4;
   }
   
   public String getFileName5() {
      return fileName5;
   }
   public void setFileName5(String fileName5) {
      this.fileName5 = fileName5;
   }
   public MultipartFile getAttch1() {
      return attch1;
   }
   public void setAttch1(MultipartFile attch1) {
      this.attch1 = attch1;
   }
   public MultipartFile getAttch2() {
      return attch2;
   }
   public void setAttch2(MultipartFile attch2) {
      this.attch2 = attch2;
   }
   public MultipartFile getAttch3() {
      return attch3;
   }
   public void setAttch3(MultipartFile attch3) {
      this.attch3 = attch3;
   }
   public MultipartFile getAttch4() {
      return attch4;
   }
   public void setAttch4(MultipartFile attch4) {
      this.attch4 = attch4;
   }
   public MultipartFile getAttch5() {
      return attch5;
   }
   public void setAttch5(MultipartFile attch5) {
      this.attch5 = attch5;
   }
   
   public String getDetailImg1() {
      return detailImg1;
   }
   public void setDetailImg1(String detailImg1) {
      this.detailImg1 = detailImg1;
   }
   public String getDetailImg2() {
      return detailImg2;
   }
   public void setDetailImg2(String detailImg2) {
      this.detailImg2 = detailImg2;
   }
   public String getDetailImg3() {
      return detailImg3;
   }
   public void setDetailImg3(String detailImg3) {
      this.detailImg3 = detailImg3;
   }
   public String getDetailImg4() {
      return detailImg4;
   }
   public void setDetailImg4(String detailImg4) {
      this.detailImg4 = detailImg4;
   }
   public String getDetailImg5() {
      return detailImg5;
   }
   public void setDetailImg5(String detailImg5) {
      this.detailImg5 = detailImg5;
   }

   public String getInternet() {
      return internet;
   }

   public void setInternet(String internet) {
      this.internet = internet;
   }
}