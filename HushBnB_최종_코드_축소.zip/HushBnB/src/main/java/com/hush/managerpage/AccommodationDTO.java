package com.hush.managerpage;

import org.springframework.web.multipart.MultipartFile;

public class AccommodationDTO {

      private String codeNum;
      private String regionSeq;
      private String name;
      private String address;
      private String mainImg;
      private String fileName;
      private String checkIn;
      private String checkOut;
      private String price;
      private String breakFirst;
      private String totalZzim;
      private String bathroom;
      private String bed;
      private String room;
      private String gender;
      
      
      public String getCodeNum() {
         return codeNum;
      }
      public void setCodeNum(String codeNum) {
         this.codeNum = codeNum;
      }
      public String getRegionSeq() {
         return regionSeq;
      }
      public void setRegionSeq(String regionSeq) {
         this.regionSeq = regionSeq;
      }
      public String getName() {
         return name;
      }
      public void setName(String name) {
         this.name = name;
      }
      public String getAddress() {
         return address;
      }
      public void setAddress(String address) {
         this.address = address;
      }
      public String getMainImg() {
         return mainImg;
      }
      public void setMainImg(String mainImg) {
         this.mainImg = mainImg;
      }
      public String getCheckIn() {
         return checkIn;
      }
      public void setCheckIn(String checkIn) {
         this.checkIn = checkIn;
      }
      public String getCheckOut() {
         return checkOut;
      }
      public void setCheckOut(String checkOut) {
         this.checkOut = checkOut;
      }
      public String getPrice() {
         return price;
      }
      public void setPrice(String price) {
         this.price = price;
      }
      public String getBreakFirst() {
         return breakFirst;
      }
      public void setBreakFirst(String breakFirst) {
         this.breakFirst = breakFirst;
      }
      public String getTotalZzim() {
         return totalZzim;
      }
      public void setTotalZzim(String totalZzim) {
         this.totalZzim = totalZzim;
      }
      public String getBathroom() {
         return bathroom;
      }
      public void setBathroom(String bathroom) {
         this.bathroom = bathroom;
      }
      public String getBed() {
         return bed;
      }
      public void setBed(String bed) {
         this.bed = bed;
      }
      public String getRoom() {
         return room;
      }
      public void setRoom(String room) {
         this.room = room;
      }
   
      public String getGender() {
         return gender;
      }

      public void setGender(String gender) {
         this.gender = gender;
      }
   
     public String getFileName() {
        return fileName;
     }
 
     public void setFileName(String fileName) {
        this.fileName = fileName;
     }
   
}