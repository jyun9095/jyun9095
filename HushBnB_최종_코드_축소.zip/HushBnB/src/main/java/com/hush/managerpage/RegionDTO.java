package com.hush.managerpage;

public class RegionDTO {
   private String seq;
   private String citySeq;
   private String region;
   
   public String getSeq() {
      return seq;
   }
   public void setSeq(String seq) {
      this.seq = seq;
   }
   public String getCitySeq() {
      return citySeq;
   }
   public void setCitySeq(String citySeq) {
      this.citySeq = citySeq;
   }
   public String getRegion() {
      return region;
   }
   public void setRegion(String region) {
      this.region = region;
   }
}