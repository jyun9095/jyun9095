package com.hush.managerpage;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hush.auth.FileManager;
import com.hush.main.Menu;

@Controller
public class ManagerPageController {

	@Autowired
	private ManagerPageDAO dao;

	@Autowired
	private FileManager fileManager;
	
	@Autowired
	private Menu menu;

	private HashMap<String, Object> map; // 어떠한 메뉴던지

	@RequestMapping(value = "/manager/managerpage/member/list.hush", method = { RequestMethod.GET })
	public String list(HttpServletRequest req, HttpSession session) {

		List<MemberManageDTO> list = dao.list();

		for (int i = 0; i < list.size(); i++) {

			// 남,여 전처리
			if (list.get(i).getGender().equals("f")) {
				list.get(i).setGender("여");
			} else {
				list.get(i).setGender("남");
			}

			// 날짜 전처리
			System.out.println(list.get(i));
			String temp = list.get(i).getBirth().substring(0, 10);
			list.get(i).setBirth(temp);

		}

		List<Integer> analysis = dao.analysis();
		List<HashMap<String, String>> clist = new ArrayList<HashMap<String, String>>();

		HashMap<String, String> map2 = new HashMap<String, String>();

		map2.put("gender", "여자");
		map2.put("value", analysis.get(0) + "");
		clist.add(map2);

		map2 = new HashMap<String, String>();

		map2.put("gender", "남자");
		map2.put("value", analysis.get(1) + "");
		clist.add(map2);

		List<Integer> analysisage = dao.analysisage();
		List<HashMap<String, String>> alist = new ArrayList<HashMap<String, String>>();

		HashMap<String, String> amap = new HashMap<String, String>();

		amap.put("age", "10대");
		amap.put("value", analysisage.get(0) + "");
		alist.add(amap);

		amap = new HashMap<String, String>();

		amap.put("age", "20대");
		amap.put("value", analysisage.get(1) + "");
		alist.add(amap);

		amap = new HashMap<String, String>();

		amap.put("age", "30대");
		amap.put("value", analysisage.get(2) + "");
		alist.add(amap);
		amap = new HashMap<String, String>();

		amap.put("age", "40대");
		amap.put("value", analysisage.get(3) + "");
		alist.add(amap);

		amap = new HashMap<String, String>();

		amap.put("age", "50대");
		amap.put("value", analysisage.get(4) + "");
		alist.add(amap);
		
		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		req.setAttribute("list", list);
		req.setAttribute("clist", clist);
		req.setAttribute("alist", alist);

		return "managerpage/list";
	}

	@RequestMapping(value = "/manager/managerpage/accommodation/list.hush", method = { RequestMethod.GET })
	public String list(HttpServletRequest req, String citySeq,
			String regionSeq, String codeNum, HttpSession session) {

		List<CityDTO> list = dao.cityList();
		if (citySeq != null) {

			int citySeq_n = Integer.parseInt(citySeq);
			List<RegionDTO> regionList = dao.regionList(citySeq_n);
			req.setAttribute("regionList", regionList);

		}

		List<AccommodationDTO> accomList = new ArrayList<AccommodationDTO>();

		if (regionSeq != null) { // 선택해서 들어오는 경우
			accomList = dao.getAccommodation(regionSeq);
			System.out.println("regionSeq있을 때 accomList size : "
					+ accomList.size());
			System.out.println("regionSeq : " + regionSeq);
		} else {
			accomList = dao.getAccommodation();
			System.out.println("regionSeq없을 때 accomList size : "
					+ accomList.size());
			regionSeq = "0";
		}

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		
		req.setAttribute("accomList", accomList);
		req.setAttribute("citySeq", citySeq);
		req.setAttribute("regionSeq", regionSeq);
		req.setAttribute("list", list);

		return "managerpage/accommodation";

	}

	@RequestMapping(value = "/manager/managerpage/accommodation/add.hush", method = { RequestMethod.GET })
	public String result(HttpServletRequest req, String citySeq,
			String regionSeq, String codeNum, HttpSession session) {

		List<CityDTO> list = dao.cityList();

		if (citySeq != null) {

			int citySeq_n = Integer.parseInt(citySeq);
			List<RegionDTO> regionList = dao.regionList(citySeq_n);
			req.setAttribute("regionList", regionList);

		}
		
		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		req.setAttribute("citySeq", citySeq);
		req.setAttribute("list", list);

		return "managerpage/add";
	}

	@RequestMapping(value = "/manager/managerpage/accommodation/accommodationok.hush", method = { RequestMethod.POST })
	public String accommodationOk(HttpServletRequest req, ImgDTO dto,
			HttpSession session) {

		System.out.println("Name : " + dto.getName());
		System.out.println("address : " + dto.getAddress());
		System.out.println("mainImg : " + dto.getAttch());
		System.out.println("checkIn : " + dto.getCheckIn());
		System.out.println("checkOut : " + dto.getCheckOut());
		System.out.println("price : " + dto.getPrice());
		System.out.println("Totalzzim : " + dto.getTotalZzim());
		System.out.println("bathroom : " + dto.getBathroom());
		System.out.println("bed : " + dto.getBed());
		System.out.println("room :" + dto.getRoom());
		System.out.println("gender : " + dto.getGender());
		System.out.println("break : " + dto.getBreakFirst());
		System.out.println("inter : " + dto.getInternet());
		System.out.println("ele : " + dto.getElevator());
		System.out.println("tv : " + dto.getTv());
		System.out.println("wash :" + dto.getWashingMachine());
		System.out.println("dry : " + dto.getHairDryer());
		System.out.println("pool : " + dto.getPool());
		System.out.println("park : " + dto.getParkingLot());
		System.out.println("detail : " + dto.getAttch1());
		System.out.println("detail2 : " + dto.getAttch2());
		System.out.println("detail3 : " + dto.getAttch3());
		System.out.println("detail4 : " + dto.getAttch4());
		System.out.println("detail5 : " + dto.getAttch5());

		// 파일 첨부 작업
		String root = session.getServletContext().getRealPath("/");
		String path = root + "images\\accommodation";
		
		System.out.println("++++++++++++++++++++++++++++++path : " + path);

		// 저장 할 파일명
		String newFileName = "";

		// 첨부 파일이 잇는지?
		if (!dto.getAttch().isEmpty()) {
			// 첨부파일을 서버에 저장하기
			byte[] bytes = null;

			try {
				bytes = dto.getAttch().getBytes();

				// 실제파일저장 + 저장 파일명 반환
				newFileName = fileManager.doFileUpload(bytes, dto.getAttch1()
						.getOriginalFilename(), path);

				// 추가 작업
				// - 사용자가 첨부한 원본 파일명
				dto.setMainImg(dto.getAttch().getOriginalFilename());
				// - 실제 서버에 저장되는 파일명
				dto.setFileName(newFileName); // 20150825105124256019534376722.jpg

				// tick 값을 사용하므로서 이름 충돌 방지

			} catch (Exception e) {
				System.out.println(e.toString());
			}
		} else {
			dto.setMainImg("");
			dto.setFileName("");
		}
		
		path = root + "images\\detailImg";

		if (!dto.getAttch1().isEmpty()) {
			// 첨부파일을 서버에 저장하기
			byte[] bytes = null;

			try {
				bytes = dto.getAttch1().getBytes();

				// 실제파일저장 + 저장 파일명 반환
				newFileName = fileManager.doFileUpload(bytes, dto.getAttch1()
						.getOriginalFilename(), path);

				// 추가 작업
				// - 사용자가 첨부한 원본 파일명
				dto.setDetailImg1(dto.getAttch1().getOriginalFilename());
				// - 실제 서버에 저장되는 파일명
				dto.setFileName1(newFileName); // 20150825105124256019534376722.jpg

				// tick 값을 사용하므로서 이름 충돌 방지

			} catch (Exception e) {
				System.out.println(e.toString());
			}
		} else {
			dto.setDetailImg1("");
			dto.setFileName1("");
		}

		if (!dto.getAttch2().isEmpty()) {
			// 첨부파일을 서버에 저장하기
			byte[] bytes = null;

			try {
				bytes = dto.getAttch2().getBytes();

				// 실제파일저장 + 저장 파일명 반환
				newFileName = fileManager.doFileUpload(bytes, dto.getAttch2()
						.getOriginalFilename(), path);

				// 추가 작업
				// - 사용자가 첨부한 원본 파일명
				dto.setDetailImg2(dto.getAttch2().getOriginalFilename());
				// - 실제 서버에 저장되는 파일명
				dto.setFileName2(newFileName); // 20150825105124256019534376722.jpg

				// tick 값을 사용하므로서 이름 충돌 방지

			} catch (Exception e) {
				System.out.println(e.toString());
			}
		} else {
			dto.setDetailImg2("");
			dto.setFileName2("");
		}

		if (!dto.getAttch3().isEmpty()) {
			// 첨부파일을 서버에 저장하기
			byte[] bytes = null;

			try {
				bytes = dto.getAttch3().getBytes();

				// 실제파일저장 + 저장 파일명 반환
				newFileName = fileManager.doFileUpload(bytes, dto.getAttch3()
						.getOriginalFilename(), path);

				// 추가 작업
				// - 사용자가 첨부한 원본 파일명
				dto.setDetailImg3(dto.getAttch3().getOriginalFilename());
				// - 실제 서버에 저장되는 파일명
				dto.setFileName3(newFileName); // 20150825105124256019534376722.jpg

				// tick 값을 사용하므로서 이름 충돌 방지

			} catch (Exception e) {
				System.out.println(e.toString());
			}
		} else {
			dto.setDetailImg3("");
			dto.setFileName3("");
		}

		if (!dto.getAttch4().isEmpty()) {
			// 첨부파일을 서버에 저장하기
			byte[] bytes = null;

			try {
				bytes = dto.getAttch4().getBytes();

				// 실제파일저장 + 저장 파일명 반환
				newFileName = fileManager.doFileUpload(bytes, dto.getAttch4()
						.getOriginalFilename(), path);

				// 추가 작업
				// - 사용자가 첨부한 원본 파일명
				dto.setDetailImg4(dto.getAttch4().getOriginalFilename());
				// - 실제 서버에 저장되는 파일명
				dto.setFileName4(newFileName); // 20150825105124256019534376722.jpg

				// tick 값을 사용하므로서 이름 충돌 방지

			} catch (Exception e) {
				System.out.println(e.toString());
			}
		} else {
			dto.setDetailImg4("");
			dto.setFileName4("");
		}

		if (!dto.getAttch5().isEmpty()) {
			// 첨부파일을 서버에 저장하기
			byte[] bytes = null;

			try {
				bytes = dto.getAttch5().getBytes();

				// 실제파일저장 + 저장 파일명 반환
				newFileName = fileManager.doFileUpload(bytes, dto.getAttch5()
						.getOriginalFilename(), path);

				// 추가 작업
				// - 사용자가 첨부한 원본 파일명
				dto.setDetailImg5(dto.getAttch5().getOriginalFilename());
				// - 실제 서버에 저장되는 파일명
				dto.setFileName5(newFileName); // 20150825105124256019534376722.jpg

				// tick 값을 사용하므로서 이름 충돌 방지

			} catch (Exception e) {
				System.out.println(e.toString());
			}
		} else {
			dto.setDetailImg5("");
			dto.setFileName5("");
		}

		System.out.println("mainImg : " + dto.getMainImg());

		int accomsave = dao.accomsave(dto); // tblAccommodation
		int accomsave1 = dao.accomsave1(dto); // tblAmenity
		int accomsave2 = dao.accomsave2(dto); // tblDetailImg

		System.out.println("accomsave : " + accomsave);
		System.out.println("accomsave1 : " + accomsave1);
		System.out.println("accomsave2 : " + accomsave2);

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		
		req.setAttribute("accomsave", accomsave);
		req.setAttribute("accomsave1", accomsave1);
		req.setAttribute("accomsave2", accomsave2);

		return "managerpage/accommodationok";
	}

	@RequestMapping(value = "/manager/managerpage/zzimmanage.hush", method = { RequestMethod.GET })
	public String zzimManage(HttpServletRequest req, HttpSession session) {

		String id = (String) session.getAttribute("id");

		Calendar now = Calendar.getInstance();
		System.out.println("now : " + String.format("%tF", now));
		now.add(Calendar.DATE, 7); // 접속날짜에서 7일 더한거

		String nowDay = String.format("%tF", now);
		System.out.println("nowDay : " + nowDay);

		HashMap<String, String> map2 = new HashMap<String, String>();
		List<ZzimManageDTO> result_list = new ArrayList<ZzimManageDTO>();
		map2.put("nowDay", nowDay);

		if (id != null) {
			if (id.equals("hushAdmin")) { // 관리자일때

				// 접속날짜 + 7인 날짜에 dDay로 찜된 숙박코드명과 카운트를 가져와
				List<ZzimManageDTO> list = dao.zzimManage(nowDay);
				
				now.add(Calendar.DATE, -7); // 접속날짜

				nowDay = String.format("%tF", now);
				System.out.println("nowDay : " + nowDay);

				System.out.println("매니져 카운트 list size : " + list.size());
				for (int i = 0; i < list.size(); i++) {
					ZzimManageDTO dto = list.get(i);

					if (Integer.parseInt(dto.getCnt()) == 3) {
						
						System.out.println("☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆☆");

						map2.put("accommodationCodeNum",
								dto.getAccommodationCodeNum());

						// 성사찜을 찾은 다음에 id 3개를 가져오기위해
						List<ZzimManageDTO> s_list = dao.successZzim(map2);

						System.out.println("s_list size : " + s_list.size());

						String ids = "";
						ZzimManageDTO s_dto = null;
						
						int cnt = 0;

						for (int j = 0; j < s_list.size(); j++) {

							s_dto = s_list.get(j);

							if (j < s_list.size() - 1)
								ids += s_dto.getId() + ",";
							else
								ids += s_dto.getId();
							
							
							s_dto.setNowDay(nowDay);

							System.out
									.println("-----------id : " + s_dto.getId());
							cnt = dao.checkMessage(s_dto);
							
						}
						
						if (cnt == 0) {

							dto.setIds(ids);
							dto.setName(s_dto.getName());
							dto.setAccommodationCodeNum(s_dto
									.getAccommodationCodeNum());
							dto.setdDay(s_dto.getdDay().substring(0, 10));
							dto.setAddress(s_dto.getAddress());
							dto.setPrice(s_dto.getPrice());

							result_list.add(dto);
						}
					}
				}

				System.out.println("result_list size : " + result_list.size());
				System.out.println("---------------성사된거지롱--------------");

				for (int i = 0; i < result_list.size(); i++) {

					ZzimManageDTO dto = result_list.get(i);

					System.out
							.println("**********************************************8");
					System.out.println("Name : " + dto.getName());
					System.out.println("AccommodationCodeNum : "
							+ dto.getAccommodationCodeNum());
					System.out.println("dDay : " + dto.getdDay());
					System.out.println("Address : " + dto.getAddress());
					System.out.println("Price : " + dto.getPrice());
					System.out.println("Ids : " + dto.getIds());

					System.out
							.println("**********************************************8");
				}
			}
		}
		
		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		req.setAttribute("list", result_list);

		return "managerpage/zzimManage";
	}

	@RequestMapping(value = "/manager/managerpage/zzimmessage.hush", method = { RequestMethod.POST })
	public String zzimMessage(HttpServletRequest req, ZzimManageDTO dto, HttpSession session) {

		System.out.println("name : " + dto.getName());
		System.out.println("dDay : " + dto.getdDay());
		System.out.println("ids : " + dto.getIds());

		boolean resultMessage = false;

		String[] ids = dto.getIds().split(",");

		for (int i = 0; i < ids.length; i++) {
			System.out.println("id : " + ids[i]);

			dto.setId(ids[i]);
			int result = dao.zzimMessage(dto);

			System.out.printf("result %d : %d\r\n", i, result);

			if (result == 1) {
				resultMessage = true;
			} else {
				resultMessage = false;
			}
		}

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		
		req.setAttribute("result", resultMessage);

		return "managerpage/zzimMessage";
	}

}