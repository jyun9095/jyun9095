package com.hush.managerpage;

import org.springframework.web.multipart.MultipartFile;

public class DetailImgDTO {

   private String seq;
   private String codeNum;
   private String datailImg1;
   private String fileName1;
   private String datailImg2;
   private String fileName2;
   private String datailImg3;
   private String fileName3;
   private String datailImg4;
   private String fileName4;
   private String datailImg5;
   private String fileName5;
   private MultipartFile attch1;
   private MultipartFile attch2;
   private MultipartFile attch3;
   private MultipartFile attch4;
   private MultipartFile attch5;
   
   public MultipartFile getAttch1() {
      return attch1;
   }
   public void setAttch1(MultipartFile attch1) {
      this.attch1 = attch1;
   }
   public MultipartFile getAttch2() {
      return attch2;
   }
   public void setAttch2(MultipartFile attch2) {
      this.attch2 = attch2;
   }
   public MultipartFile getAttch3() {
      return attch3;
   }
   public void setAttch3(MultipartFile attch3) {
      this.attch3 = attch3;
   }
   public MultipartFile getAttch4() {
      return attch4;
   }
   public void setAttch4(MultipartFile attch4) {
      this.attch4 = attch4;
   }
   public MultipartFile getAttch5() {
      return attch5;
   }
   public void setAttch5(MultipartFile attch5) {
      this.attch5 = attch5;
   }
   public String getSeq() {
      return seq;
   }
   public void setSeq(String seq) {
      this.seq = seq;
   }
   public String getCodeNum() {
      return codeNum;
   }
   public void setCodeNum(String codeNum) {
      this.codeNum = codeNum;
   }
   public String getDatailImg1() {
      return datailImg1;
   }
   public void setDatailImg1(String datailImg1) {
      this.datailImg1 = datailImg1;
   }
   public String getFileName1() {
      return fileName1;
   }
   public void setFileName1(String fileName1) {
      this.fileName1 = fileName1;
   }
   public String getDatailImg2() {
      return datailImg2;
   }
   public void setDatailImg2(String datailImg2) {
      this.datailImg2 = datailImg2;
   }
   public String getFileName2() {
      return fileName2;
   }
   public void setFileName2(String fileName2) {
      this.fileName2 = fileName2;
   }
   public String getDatailImg3() {
      return datailImg3;
   }
   public void setDatailImg3(String datailImg3) {
      this.datailImg3 = datailImg3;
   }
   public String getFileName3() {
      return fileName3;
   }
   public void setFileName3(String fileName3) {
      this.fileName3 = fileName3;
   }
   public String getDatailImg4() {
      return datailImg4;
   }
   public void setDatailImg4(String datailImg4) {
      this.datailImg4 = datailImg4;
   }
   public String getFileName4() {
      return fileName4;
   }
   public void setFileName4(String fileName4) {
      this.fileName4 = fileName4;
   }
   public String getDatailImg5() {
      return datailImg5;
   }
   public void setDatailImg5(String datailImg5) {
      this.datailImg5 = datailImg5;
   }
   public String getFileName5() {
      return fileName5;
   }
   public void setFileName5(String fileName5) {
      this.fileName5 = fileName5;
   }
   
}