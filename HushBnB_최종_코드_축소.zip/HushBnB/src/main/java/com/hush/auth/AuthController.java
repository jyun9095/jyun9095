package com.hush.auth;

import java.math.BigInteger;
import java.security.SecureRandom;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class AuthController {

	@Resource(name = "fileManager")
	private FileManager fileManager;
	@Autowired
	private AuthDAO dao; // 의존주입

	@RequestMapping(value = "/auth/login.hush", method = { RequestMethod.GET })
	public String login(HttpServletRequest req, String error) {
		/*
		 * String error = error; if()
		 */
		System.out.println(error);
		req.setAttribute("error", error);
		return "auth/login";
	}

	@RequestMapping(value = "/auth/loginok.hush", method = { RequestMethod.POST })
	public String loginok(HttpServletRequest req, MemberDTO dto, HttpSession session) {

		// DAO 호출해서 판단
		// 1. 성공 2. 비번실패, 3. 존재하지 않는 아이디

		// 1. 성공 -> result : 0
		// 2. 비번 시류ㅐ -> result :1
		// 3. 존재하지않는 아이디 -> result :2

		int result = 0;
		result = dao.checkMember(dto);
		if (result == 0) {
			session.setAttribute("id", dto.getId());
		}
		System.out.println(dto.getId());
		System.out.println("result : " + result);

		req.setAttribute("result", result);
		return "auth/loginok";

	}

	@RequestMapping(value = "/auth/joinnaver.hush", method = { RequestMethod.GET })
	public String joinNaver() {

		return "auth/joinNaver";

	}

	@RequestMapping(value = "/auth/joinnaverok.hush", method = { RequestMethod.POST })
	public String joinNaverOk(HttpServletRequest req, AuthDTO dto) {

		/*
		 * 
		 * String result = dao.joinNaver(dto); // 글쓰기
		 * 
		 * String tel1 = dto.getTel(); // 010,2711,6904
		 * 
		 * String tel4 = tel1.substring(0, 3); String tel2 = tel1.substring(4,
		 * 8); String tel3 = tel1.substring(9, 13);
		 * 
		 * String tel = tel4 + "-" + tel2 + "-" + tel3; dto.setTel(tel); //
		 * 0날짜/나이처리 String birth = dto.getBirth(); birth = birth.substring(0,
		 * 4); System.out.println("birth : " + birth); String age = 2015 -
		 * Integer.parseInt(birth) + 1 + ""; dto.setAge(age);
		 * 
		 * // 성별처리 String gender = dto.getGender();
		 * 
		 * System.out.println(`gender : " + gender);
		 * 
		 * System.out.println("age : " + age); int result = dao.join(dto); //
		 * 글쓰기
		 * 
		 * req.setAttribute("result", result);
		 * 
		 * 
		 */

		String image = dto.getImage();
		String tel = dto.getTel();

		System.out.println("image :" + image);

		String tel5 = dto.getTel();
		// 010,2711,6904

		String tel6 = tel5.substring(0, 3);
		String tel7 = tel5.substring(4, 8);
		String tel8 = tel5.substring(9, 13);

		tel = tel6 + "-" + tel7 + "-" + tel8;
		dto.setTel(tel);
		System.out.println("tel : " + tel);

		int result = dao.joinNaver(dto); // 글쓰기

		System.out.println("result 컨트롤러 : " + result);

		req.setAttribute("result", result);

		return "auth/joinNaverOk";

	}

	@RequestMapping(value = "/auth/join.hush", method = { RequestMethod.GET })
	public String join() {

		return "auth/join";
	}

	// 글쓰기 완료
	@RequestMapping(value = "/auth/joinok.hush", method = { RequestMethod.POST })
	public String joinOk(HttpServletRequest req, AuthDTO dto, HttpSession session) { // 1.

		// 1. 데이터 가져오기(DTO)
		// 2. DAO 위임(insert) m
		// 3. 완료 메시지 -> JSP 호출(위임)

		/*
		 * //전처리 //System.out.println(dto.getTag()); if (dto.getTag() == null) {
		 * dto.setTag("n"); } else { dto.setTag("y"); }
		 * 
		 */
		// 핸드폰 전화번호 처리

		// 파일 첨부 작업
		String root = session.getServletContext().getRealPath("/");
		String path = root + "images";

		System.out.println("++++++++path : " + path);
		
		// 저장할 파일명
		String newFileName = "";

		// 첨부 파일을 있는지?
		if (!dto.getAttch().isEmpty()) {

			// 첨부파일을 서버에 저장하기
			byte[] bytes = null;

			try {

				bytes = dto.getAttch().getBytes();

				// 실제 파일 저장 + 저장 파일명 반환
				newFileName = fileManager.doFileUpload(bytes, dto.getAttch().getOriginalFilename(), path);

				// 추가 작업
				// - 사용자가 첨부한 원본 파일명
				dto.setImage(dto.getAttch().getOriginalFilename());
				// - 실제 서버에 저장되는 파일명
				dto.setFileName(newFileName);

			} catch (Exception e) {
				System.out.println(e.toString());
			}

		} else {
			dto.setImage("");
			dto.setFileName("");
		}

		String tel1 = dto.getTel();
		// 010,2711,6904

		String tel4 = tel1.substring(0, 3);
		String tel2 = tel1.substring(4, 8);
		String tel3 = tel1.substring(9, 13);

		String tel = tel4 + "-" + tel2 + "-" + tel3;
		dto.setTel(tel);

		// e-mail 처리
		String email = dto.getEmail();

		dto.setEmail(dto.getEmail().replace(",", "@"));
		/* dto.setAge(); */

		System.out.println("email : " + email);

		// 0날짜/나이처리
		String birth = dto.getBirth();
		birth = birth.substring(0, 4);
		System.out.println("birth : " + birth);
		String age = 2015 - Integer.parseInt(birth) + 1 + "";
		dto.setAge(age);

		System.out.println("age : " + age);

		// 성별처리

		String gender = dto.getGender();
		dto.setGender(dto.getGender().replace("m", "m"));

		dto.setGender(dto.getGender().replace("f", "f"));

		System.out.println("gender : " + gender);

		int result = dao.join(dto); // 글쓰기

		req.setAttribute("result", result);

		return "auth/joinOk";
	}

	@RequestMapping(value = "/auth/idsearch.hush", method = { RequestMethod.GET })
	public String idSearch() {

		return "auth/idSearch";
	}

	@RequestMapping(value = "/auth/idsearchok.hush", method = { RequestMethod.POST })
	public String idSearch(HttpServletRequest req, AuthDTO dto) { // 1.

		// 1. 데이터 가져오기(DTO)
		// 2. DAO 위임(insert) m
		// 3. 완료 메시지 -> JSP 호출(위임)

		String email = dto.getEmail();

		System.out.println("email : " + email);
		dto.setEmail(dto.getEmail().replace(",", "@"));
		/* dto.setAge(); */

		String result = dao.idsearch(dto); // 글쓰기

		req.setAttribute("result", result);

		return "auth/idSearchOk";
	}

	@RequestMapping(value = "/auth/pwsearch.hush", method = { RequestMethod.GET })
	public String pwSearch() {

		return "auth/pwSearch";
	}

	@RequestMapping(value = "/auth/pwsearchok.hush", method = { RequestMethod.POST })
	public String pwSearch(HttpServletRequest req, AuthDTO dto) { // 1.

		// 1. 데이터 가져오기(DTO)
		// 2. DAO 위임(insert) m
		// 3. 완료 메시지 -> JSP 호출(위임)

		String email = dto.getEmail();
		String id = dto.getId();
		System.out.println("id :" + id);
		System.out.println("email : " + email);
		dto.setEmail(dto.getEmail().replace(",", "@"));
		/* dto.setAge(); */

		String result = dao.pwsearch(dto); // 글쓰기

		req.setAttribute("result", result);

		return "auth/pwSearchOk";
	}

	@RequestMapping(value = "/auth/idcheck.hush", method = { RequestMethod.GET })
	public String idcheck(HttpServletRequest req) {

		// 아이디 중복 검사

		String id = req.getParameter("id");

		int result = dao.idcheck(id);

		req.setAttribute("result", result);

		return "auth/idCheck";
	}

	

	@RequestMapping(value = "/auth/logout.hush", method = { RequestMethod.GET })
	public String logout(HttpSession session, HttpServletRequest req) { // 1.

		// 세션 비우기
		String id = (String) session.getAttribute("id");
		int result = 0;

		if (id != null) {
			session.invalidate();
			result = 1;
		}

		req.setAttribute("result", result);

		return "auth/logout";
	}

	@RequestMapping(value = "/auth/joinchoice.hush", method = { RequestMethod.GET })
	public String joinChoice() {

		return "auth/joinChoice";
	}

	@RequestMapping(value = "/auth/joinnavercheck.hush", method = { RequestMethod.GET })
	public String joinNaverCheck(HttpServletRequest req, HttpSession session) {

		// CSRF 방지를 위한 상태 토큰 생성 코드
		// 상태 토큰은 추후 검증을 위해 세션에 저장되어야 한다.

		// 상태 토큰으로 사용할 랜덤 문자열 생성
		String state = generateState();
		// 세션 또는 별도의 저장 공간에 상태 토큰을 저장
		session.setAttribute("state", state);
		System.out.println(state);

		return "auth/joinNaverCheck";
	}

	@RequestMapping(value = "/auth/joinnavercheckok.hush", method = { RequestMethod.GET })
	public String joinNaverCheckOk(HttpServletRequest req, HttpSession session) {

		return "auth/joinNaverCheckOk";
	}

	public String generateState() {
		SecureRandom random = new SecureRandom();
		return new BigInteger(130, random).toString(32);
	}

}