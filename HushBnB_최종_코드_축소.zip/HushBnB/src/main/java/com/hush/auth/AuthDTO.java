package com.hush.auth;

import org.springframework.web.multipart.MultipartFile;

public class AuthDTO {

   private String id;
   private String txt;
   private String num;
   private String checkin;
   private String checkout;
   private String pw;
   private String lv;
   private String image;
   private String name;
   private String birth;
   private String age;
   private String gender;
   private String tel;
   private String email;


   //*** 첨부파일
   // - <input type="file" name="attch" />
   private MultipartFile attch;
   
   private String fileName;
   private String orgFileName;
   private String price;
   
   public String getId() {
      return id;
   }

   public void setId(String id) {
      this.id = id;
   }

   public String getPw() {
      return pw;
   }

   public void setPw(String pw) {
      this.pw = pw;
   }

   public String getLv() {
      return lv;
   }

   public void setLv(String lv) {
      this.lv = lv;
   }

   public String getImage() {
      return image;
   }

   public void setImage(String image) {
      this.image = image;
   }

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public String getBirth() {
      return birth;
   }

   public void setBirth(String birth) {
      this.birth = birth;
   }

   public String getAge() {
      return age;
   }

   public void setAge(String age) {
      this.age = age;
   }

   public String getGender() {
      return gender;
   }

   public void setGender(String gender) {
      this.gender = gender;
   }

   public String getTel() {
      return tel;
   }

   public void setTel(String tel) {
      this.tel = tel;
   }

   public String getEmail() {
      return email;
   }

   public void setEmail(String email) {
      this.email = email;
   }
   
   public String getTxt() {
      return txt;
   }

   public void setTxt(String txt) {
      this.txt = txt;
   }

   public String getNum() {
      return num;
   }

   public void setNum(String num) {
      this.num = num;
   }

   public MultipartFile getAttch() {
      return attch;
   }

   public void setAttch(MultipartFile attch) {
      this.attch = attch;
   }

   public String getFileName() {
      return fileName;
   }

   public void setFileName(String fileName) {
      this.fileName = fileName;
   }

   public String getOrgFileName() {
      return orgFileName;
   }

   public void setOrgFileName(String orgFileName) {
      this.orgFileName = orgFileName;
   }

   public String getPrice() {
      return price;
   }

   public void setPrice(String price) {
      this.price = price;
   }


   public String getCheckin() {
      return checkin;
   }

   public void setCheckin(String checkin) {
      this.checkin = checkin;
   }

   public String getCheckout() {
      return checkout;
   }

   public void setCheckout(String checkout) {
      this.checkout = checkout;
   }


   private String address;
   public String getAddress() {
      return address;
   }

   public void setAddress(String address) {
      this.address = address;
   }
}