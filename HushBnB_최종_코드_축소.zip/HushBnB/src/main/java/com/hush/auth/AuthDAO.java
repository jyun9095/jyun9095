package com.hush.auth;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class AuthDAO {

	@Autowired
	private SqlSessionTemplate sql;

	public int checkMember(MemberDTO dto) {

		int result1;
		int result2;
		int result3;
		int a = 0;
		System.out.println(dto.getId());
		System.out.println(dto.getPw());

		result1 = sql.selectOne("auth.checkMember", dto); // 아뒤 비번 맞으면 1
		result2 = sql.selectOne("auth.idError", dto); // 아이디가 있으면 1
		result3 = sql.selectOne("auth.pwError", dto); // 아뒤가 맞는데 비번이 틀리면 1

		System.out.println("DAO result1 : " + result1);
		System.out.println("DAO result2 : " + result2);
		System.out.println("DAO result3 : " + result3);

		if (result1 == 1 && result2 == 1 && result3 == 1) {

			a = 0; // 아뒤 비번 맞으면 1

		} else if (result1 == 0 && result2 == 0 && result3 == 0) {
			a = 1; // 아이디가 있으면 1
		} else if (result1 == 0 && result2 == 1 && result3 == 1) {

			a = 2; // 아뒤가 맞는데 비번이 틀리면 1

		}

		// 0. 아디 o, 비밀번호o
		// 1. 아디 x, 비밀번호o
		// 2. 아디 o,비밀번호 x

		return a;
	}

	// 글쓰기 위임

	public int join(AuthDTO dto) {

		int result = 0;

		System.out.println("join" + dto.getName());

		// test.m1
		result = sql.insert("auth.join", dto);

		return result;
	}

	public boolean check(AuthDTO dto) {

		boolean result;

		int count = sql.selectOne("auth.check", dto);

		if (count == 1)
			result = true;
		else
			result = false;

		return result;

	}

	public String idsearch(AuthDTO dto) {

		String result = "";

		System.out.println("idsearch" + dto.getEmail());

		// test.m1
		result = sql.selectOne("auth.idSearch", dto);
		System.out.println(result);

		return result;

	}

	public String pwsearch(AuthDTO dto) {
		String result = "";

		System.out.println("pwsearch : " + dto.getEmail());

		System.out.println("id : " + dto.getId());

		result = sql.selectOne("auth.pwSearch", dto);
		System.out.println(result);

		return result;
	}

	public int joinNaver(AuthDTO dto) {

		int result = 0;

		// test.m1
		/* result = sql.insert("auth.joinNaver", dto); */
		result = sql.insert("auth.joinNaver", dto);
		System.out.println(result);
		return result;
	}

	public int idcheck(String id) {

		return sql.selectOne("auth.idcheck", id);
	}

}