package com.hush.mypage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hush.main.CityDTO;
import com.hush.main.RegionDTO;

@Repository
public class MyPageDAO {

	@Autowired
	private SqlSessionTemplate sql;

	public List<CityDTO> cityList() {

		List<CityDTO> list = new ArrayList<CityDTO>();

		list = sql.selectList("main.cityList");

		return list;
	}

	public List<RegionDTO> regionList(int citySeq_n) {

		return sql.selectList("main.regionList", citySeq_n);
	}

	public List<ItineraryDTO> itineraryList(String id) {

		List<ItineraryDTO> list = sql.selectList("mypage.itineraryList", id);

		return list;
	}

	public List<ZzimDTO> zzimList() {

		return null;
	}

	public String getGender(String id) {

		String gender = sql.selectOne("mypage.getGender", id);
		System.out.println("id : " + id);

		return gender;
	}

	public String getCity(String citySeq) {

		String city = sql.selectOne("mypage.getCity", citySeq);

		return city;
	}

	public int addItinerary(ItineraryDTO dto) {

		int result = 0;
		int max = 0;

		result = sql.insert("mypage.addItinerary", dto);

		if (result == 1) {
			max = sql.selectOne("mypage.maxItinerary");
			System.out.println("Itinerary max값 : " + max);
		} else {
			System.out.println("Itineraray 추가 실패");
		}

		return max;
	}

	public void addDetailItinerary(DetailItineraryDTO d_dto) {

		sql.insert("mypage.addDetailItinerary", d_dto);

	}

	public ItineraryDTO getItinerary(String id) {

		ItineraryDTO dto = sql.selectOne("mypage.getItinerary", id);

		return dto;
	}

	public List<DetailItineraryDTO> getDetailItinerary(
			HashMap<String, String> map) {

		List<DetailItineraryDTO> list = sql.selectList(
				"mypage.getDetailItinerary", map);

		return list;
	}

	public ItineraryDTO getItinerary(HashMap<String, String> i_map) {

		return sql.selectOne("mypage.getItinerary2", i_map);
	}

	public String checkRegion(String regionSeq) {

		return sql.selectOne("mypage.checkRegion", regionSeq);
	}

	public ZzimDTO successZzim(HashMap<String, String> map) {

		return sql.selectOne("mypage.successZzim", map);
	}

	public ZzimDTO getZzim(HashMap<String, String> map) {

		return sql.selectOne("mypage.getZzim", map);
	}

	public List<ZzimDTO> preZzim(HashMap<String, String> map) {

		return sql.selectList("mypage.preZzim", map);
	}

	public ZzimDTO failZzim(ZzimDTO dto) {

		return sql.selectOne("mypage.failZzim", dto);
	}

	public List<ZzimDTO> getIdZzim(HashMap<String, String> map) {
		// TODO Auto-generated method stub
		return sql.selectList("mypage.getIdZzim", map);
	}

	public ZzimAccomDTO getZzimAccom(ZzimDTO success_dto) {

		return sql.selectOne("mypage.getZzimAccom", success_dto);
	}

	public int getCount(ZzimDTO dto) {
		// TODO Auto-generated method stub
		return sql.selectOne("mypage.getCount", dto);
	}

	public List<PaymentCheckDTO> paymentCheck(String id) {

		return sql.selectList("mypage.paymentCheck", id);
	}

	public List<MessageDTO> getMessage(String id) {

		return sql.selectList("mypage.getMessage", id);
	}

	public MessageDTO getMessageView(String seq) {
		return sql.selectOne("mypage.getMessageView", seq);
	}

	public int getDetailItineraryCount(HashMap<String, String> map) {
		
		return sql.selectOne("mypage.getDetailItineraryCount", map);
	}

	public int checkPayment(ZzimDTO success_dto) {
		// TODO Auto-generated method stub
		return sql.selectOne("mypage.checkPayment", success_dto);
	}

}
