package com.hush.mypage;

public class DetailItineraryDTO {
	
	private String seq;
	private String itinerarySeq;
	private String detailDate;
	private String time;
	private String regionSeq;
	private String place;
	
	private String region;
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getItinerarySeq() {
		return itinerarySeq;
	}
	public void setItinerarySeq(String itinerarySeq) {
		this.itinerarySeq = itinerarySeq;
	}
	public String getDetailDate() {
		return detailDate;
	}
	public void setDetailDate(String detailDate) {
		this.detailDate = detailDate;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getRegionSeq() {
		return regionSeq;
	}
	public void setRegionSeq(String regionSeq) {
		this.regionSeq = regionSeq;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	

}
