package com.hush.mypage;

public class ZzimDTO {

	private String seq;
	private String id;
	private String accommodationCodeNum;
	private String zzimDate;
	private String dDay;
	
	//DB외의 데이터
	private String cnt;
	
	public String getAccommodationCodeNum() {
		return accommodationCodeNum;
	}
	public void setAccommodationCodeNum(String accommodationCodeNum) {
		this.accommodationCodeNum = accommodationCodeNum;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getZzimDate() {
		return zzimDate;
	}
	public void setZzimDate(String zzimDate) {
		this.zzimDate = zzimDate;
	}
	public String getdDay() {
		return dDay;
	}
	public void setdDay(String dDay) {
		this.dDay = dDay;
	}
	public String getCnt() {
		return cnt;
	}
	public void setCnt(String cnt) {
		this.cnt = cnt;
	}
	
}
