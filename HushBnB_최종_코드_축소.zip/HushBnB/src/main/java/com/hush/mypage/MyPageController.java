package com.hush.mypage;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hush.main.CityDTO;
import com.hush.main.Menu;
import com.hush.main.RegionDTO;

@Controller
public class MyPageController {

	@Autowired
	private MyPageDAO dao;

	@Autowired
	private Menu menu;

	private HashMap<String, Object> map; // 어떠한 메뉴던지

	// 일정 적기 form

	@RequestMapping(value = "/mypage/itinerary.hush", method = { RequestMethod.GET })
	public String itinerary(HttpServletRequest req, ItineraryDTO dto,
			HttpSession session) {

		List<CityDTO> cityList = dao.cityList();

		String citySeq = dto.getCitySeq();

		// 선택한 시/특별시에 대한 시/구/지역 리스트
		if (citySeq != null) {

			int citySeq_n = Integer.parseInt(citySeq);
			List<RegionDTO> regionList = dao.regionList(citySeq_n);
			req.setAttribute("regionList", regionList);
			req.setAttribute("citySeq", citySeq);

		}

		System.out.println("CitySeq : " + dto.getCitySeq());
		System.out.println("RegionSeq : " + dto.getRegionSeq());
		System.out.println("StartDate : " + dto.getStartDate());
		System.out.println("EndDate : " + dto.getEndDate());

		// startDate와 endDate에 따른 detailItinerary 갯수
		if (dto.getStartDate() != null && dto.getEndDate() != null) {

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			Date startDate = null;
			Date endDate = null;

			try {
				startDate = format.parse(dto.getStartDate());
				endDate = format.parse(dto.getEndDate());
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			ArrayList<String> detailDateList = new ArrayList();

			Calendar start = Calendar.getInstance();
			start.setTime(startDate);
			Calendar end = Calendar.getInstance();
			end.setTime(endDate);

			while (true) {

				// 시작날과 마지막날이 일치하면 break
				if (start.get(Calendar.YEAR) == end.get(Calendar.YEAR)
						&& start.get(Calendar.MONTH) == end.get(Calendar.MONTH)
						&& start.get(Calendar.DATE) == end.get(Calendar.DATE)) {
					break;
				}

				// yyyy-MM-dd
				detailDateList.add(String.format("%tF", start));
				start.add(Calendar.DATE, 1); // 날짜 1씩 증가
			}

			System.out.println(detailDateList.size());

			req.setAttribute("detailDateList", detailDateList);
			req.setAttribute("regionSeq", dto.getRegionSeq());
			req.setAttribute("startDate", dto.getStartDate());
			req.setAttribute("endDate", dto.getEndDate());
		}

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		req.setAttribute("cityList", cityList);

		return "mypage/itinerary";

	}

	// 일정 적기 insert Ok
	@RequestMapping(value = "/mypage/itineraryok.hush", method = { RequestMethod.POST })
	public String itineraryOk(HttpServletRequest req, ItineraryDTO dto,
			HttpSession session) {

		// seq - 자동
		// id - 로그인한걸로 자동으로
		// destination - 여행지 -> 대분류/소분류 selectBox
		// startDate - 시작날 input/date
		// endDate - 마지막날 input/date
		// peopleNum - 총인원 selectBox
		// price - 가격 selectBox 보류
		// gender - 성별 member의 성별로 자동

		// tblItinerary 전처리
		String id = (String) session.getAttribute("id");

		if (id != null) {
			dto.setId(id);
			System.out.println("id : " + id);

			String gender = dao.getGender(id);
			dto.setGender(gender);
			// System.out.println("gender : " + gender);

			String destination = dao.getCity(dto.getCitySeq());
			dto.setDestination(destination);
			// System.out.println("destination : " + destination);

			// System.out.println("+++++++++++++++++ Itinerary +++++++++++++++");
			// System.out.println("id : " + dto.getId());
			// System.out.println("destination : " + dto.getDestination());
			// System.out.println("startDate : " + dto.getStartDate());
			// System.out.println("endDate : " + dto.getEndDate());
			// System.out.println("peopleNum : " + dto.getPeopleNum());
			// System.out.println("price : " + dto.getPrice());
			// System.out.println("gender : " + dto.getGender());

			int itinerarySeq = dao.addItinerary(dto);

			System.out.println("itinerarySeq : " + itinerarySeq);

			String[] detailDateArr = req.getParameterValues("detailDate");
			String[] timeArr = req.getParameterValues("time");
			String[] regionSeqArr = req.getParameterValues("regionSeq");
			String[] placeArr = req.getParameterValues("place");
			String[] itemcountArr = req.getParameterValues("itemcount");

			// System.out.println("detailDateArr size : " +
			// detailDateArr.length);
			// System.out.println("timeArr size : " + timeArr.length);
			// System.out.println("regionSeqArr size : " + regionSeqArr.length);
			// System.out.println("placeArr size : " + placeArr.length);
			// System.out.println("itemcountArr size : " + itemcountArr.length);

			int t = 0;

			for (int i = 0; i < detailDateArr.length; i++) {

				int n = 0;
				System.out.printf("itemcount %d : %s\r\n", i, itemcountArr[i]);

				for (int j = t; j < timeArr.length; j++) {

					if (Integer.parseInt(itemcountArr[i]) > n) {

						// time 전처리
						String time = timeArr[j].substring(0, 2); // 14

						if (time.substring(0, 1).equals("0")) { // 04:00
							time = time.substring(1, 2);
						}

						if (Integer.parseInt(time) < 12) {
							timeArr[j] = "AM" + timeArr[j];
						} else {
							time = (Integer
									.parseInt(timeArr[j].substring(0, 2)) - 12)
									+ "";
							if (Integer.parseInt(time) < 10) {
								time = "0" + time;
							}
							timeArr[j] = "PM" + time + ":"
									+ timeArr[j].substring(3, 5);
						}

						DetailItineraryDTO d_dto = new DetailItineraryDTO();
						d_dto.setItinerarySeq(itinerarySeq + "");
						d_dto.setDetailDate(detailDateArr[i]);
						d_dto.setTime(timeArr[j]);
						d_dto.setRegionSeq(regionSeqArr[j]);
						d_dto.setPlace(placeArr[j]);

						System.out
								.println("----------- DetailItinerary ---------------");
						System.out.println("IninerarySeq : "
								+ d_dto.getItinerarySeq());
						System.out.println("DetailDate : "
								+ d_dto.getDetailDate());
						System.out.println("Time : " + d_dto.getTime());
						System.out.println("RegionSeq : "
								+ d_dto.getRegionSeq());
						System.out.println("Place : " + d_dto.getPlace());

						dao.addDetailItinerary(d_dto);
						n++;
						t++;
					}
				}
			}
		}

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		return "mypage/itineraryOk";

	}

	// 일정 적기 form
	@RequestMapping(value = "/mypage/itineraryform.hush", method = { RequestMethod.GET })
	public String itineraryForm(HttpServletRequest req, HttpSession session,
			String itinerarySeq) {

		System.out.println("************form이다************");
		// tblItinerary & tblDetailItinerary 리스트 가져오기

		String id = (String) session.getAttribute("id");

		System.out.println("itinerarySeq : " + itinerarySeq);

		ItineraryDTO dto = null;
		List<DetailItineraryDTO> dList = null;
		List<String> detailDateList = null;
		List<Integer> detailDateSize = new ArrayList<Integer>();

		if (itinerarySeq == null) { // 일정적기 -> 일정폼

			dto = dao.getItinerary(id);

			// StartDate, EndDate
			String startDate = dto.getStartDate().substring(0, 10);
			String endDate = dto.getEndDate().substring(0, 10);

			dto.setStartDate(startDate);
			dto.setEndDate(endDate);

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			Date start = null;
			Date end = null;

			try {
				start = format.parse(startDate);
				end = format.parse(endDate);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			Calendar startC = Calendar.getInstance();
			startC.setTime(start);
			Calendar endC = Calendar.getInstance();
			endC.setTime(end);

			// endC.add(Calendar.DATE, -1); // 디데이에서 -1 한거

			// gender 처리

			if (dto.getGender().equals("f")) {
				dto.setGender("여자");
			} else {
				dto.setGender("남자");
			}

			String iSeq = dto.getSeq();

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("id", id);
			map.put("iSeq", iSeq);

			while (true) {

				// 시작날과 마지막 전날이 일치하면 break
				if (startC.get(Calendar.YEAR) == endC.get(Calendar.YEAR)
						&& startC.get(Calendar.MONTH) == endC
								.get(Calendar.MONTH)
						&& startC.get(Calendar.DATE) == endC.get(Calendar.DATE)) {
					break;
				}

				System.out.println("♡♡♡♡♡♡date : "
						+ String.format("%tF", startC));
				map.put("date", String.format("%tF", startC));

				int cnt = dao.getDetailItineraryCount(map);

				detailDateSize.add(cnt);

				startC.add(Calendar.DATE, 1); // 날짜 1씩 증가
			}

			System.out.println("♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥");
			System.out.println("detailDateSize : " + detailDateSize.size());
			for (int i = 0; i < detailDateSize.size(); i++) {
				System.out.printf("cnt %d : %d\r\n", i, detailDateSize.get(i));
			}

			dList = dao.getDetailItinerary(map);

			System.out.println("dList size : " + dList.size());

			detailDateList = new ArrayList<String>();

			for (int i = 0; i < dList.size(); i++) {

				DetailItineraryDTO d_dto = dList.get(i);

				// DetailDate
				d_dto.setDetailDate(d_dto.getDetailDate().substring(0, 10));

				// regionSeq 처리
				String region = dao.checkRegion(d_dto.getRegionSeq());
				d_dto.setRegion(region);

				System.out.println("d_dto.getDetailDate if문 전: "
						+ d_dto.getDetailDate());

				if (i != 0) {
					boolean k = false;

					for (int j = 0; j < detailDateList.size(); j++) {
						if (!detailDateList.get(j)
								.equals(d_dto.getDetailDate())) {
							k = true;
						} else {
							k = false;
							break;
						}
					}

					if (k) {
						detailDateList.add(d_dto.getDetailDate());
					}
				} else {
					detailDateList.add(d_dto.getDetailDate());
				}

				System.out
						.println("----------- DetailItinerary ---------------");
				System.out.println("IninerarySeq : " + d_dto.getItinerarySeq());
				System.out.println("DetailDate : " + d_dto.getDetailDate());
				System.out.println("Time : " + d_dto.getTime());
				System.out.println("RegionSeq : " + d_dto.getRegionSeq());
				System.out.println("Region : " + d_dto.getRegion());
				System.out.println("Place : " + d_dto.getPlace());
			}

			for (int j = 0; j < detailDateList.size(); j++) {
				System.out.printf("detailDateList [%d] : %s\r\n", j,
						detailDateList.get(j));
			}

			System.out
					.println("detailDateList size : " + detailDateList.size());
		} else { // 일정리스트 -> 일정폼

			HashMap<String, String> i_map = new HashMap<String, String>();
			i_map.put("id", id);
			i_map.put("itinerarySeq", itinerarySeq);

			dto = dao.getItinerary(i_map);

			// StartDate, EndDate
			String startDate = dto.getStartDate().substring(0, 10);
			String endDate = dto.getEndDate().substring(0, 10);

			dto.setStartDate(startDate);
			dto.setEndDate(endDate);

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

			Date start = null;
			Date end = null;

			try {
				start = format.parse(startDate);
				end = format.parse(endDate);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			Calendar startC = Calendar.getInstance();
			startC.setTime(start);
			Calendar endC = Calendar.getInstance();
			endC.setTime(end);

			// endC.add(Calendar.DATE, -1); // 디데이에서 -1 한거

			// gender 처리

			if (dto.getGender().equals("f")) {
				dto.setGender("여자");
			} else {
				dto.setGender("남자");
			}

			String iSeq = dto.getSeq();

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("id", id);
			map.put("iSeq", iSeq);

			while (true) {

				// 시작날과 마지막 전날이 일치하면 break
				if (startC.get(Calendar.YEAR) == endC.get(Calendar.YEAR)
						&& startC.get(Calendar.MONTH) == endC
								.get(Calendar.MONTH)
						&& startC.get(Calendar.DATE) == endC.get(Calendar.DATE)) {
					break;
				}

				System.out.println("♡♡♡♡♡♡date : "
						+ String.format("%tF", startC));
				map.put("date", String.format("%tF", startC));

				int cnt = dao.getDetailItineraryCount(map);

				detailDateSize.add(cnt);

				startC.add(Calendar.DATE, 1); // 날짜 1씩 증가
			}

			System.out.println("♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥");
			System.out.println("detailDateSize : " + detailDateSize.size());
			for (int i = 0; i < detailDateSize.size(); i++) {
				System.out.printf("cnt %d : %d\r\n", i, detailDateSize.get(i));
			}

			dList = dao.getDetailItinerary(map);

			System.out.println("dList size : " + dList.size());

			detailDateList = new ArrayList<String>();

			for (int i = 0; i < dList.size(); i++) {
				DetailItineraryDTO d_dto = dList.get(i);

				// DetailDate
				d_dto.setDetailDate(d_dto.getDetailDate().substring(0, 10));

				// regionSeq 처리
				String region = dao.checkRegion(d_dto.getRegionSeq());
				d_dto.setRegion(region);

				System.out.println("d_dto.getDetailDate if문 전: "
						+ d_dto.getDetailDate());

				if (i != 0) {
					boolean k = false;

					for (int j = 0; j < detailDateList.size(); j++) {
						if (!detailDateList.get(j)
								.equals(d_dto.getDetailDate())) {
							k = true;
						} else {
							k = false;
							break;
						}
					}

					if (k) {
						detailDateList.add(d_dto.getDetailDate());
					}
				} else {
					detailDateList.add(d_dto.getDetailDate());
				}

				System.out
						.println("----------- DetailItinerary ---------------");
				System.out.println("IninerarySeq : " + d_dto.getItinerarySeq());
				System.out.println("DetailDate : " + d_dto.getDetailDate());
				System.out.println("Time : " + d_dto.getTime());
				System.out.println("RegionSeq : " + d_dto.getRegionSeq());
				System.out.println("Region : " + d_dto.getRegion());
				System.out.println("Place : " + d_dto.getPlace());
			}

			for (int j = 0; j < detailDateList.size(); j++) {
				System.out.printf("detailDateList [%d] : %s\r\n", j,
						detailDateList.get(j));
			}

			System.out
					.println("detailDateList size : " + detailDateList.size());

		}

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		req.setAttribute("dDateList", detailDateList);
		req.setAttribute("detailDateSize", detailDateSize);
		req.setAttribute("dto", dto); // 일정 DTO
		req.setAttribute("dList", dList); // 상세일정 리스트

		System.out.println("●●●●●●●●●●●●●●●●●●●●●●●●●");
		System.out.println("detailDateList size : " + detailDateList.size());
		System.out.println("detailDateSize size : " + detailDateSize.size());
		System.out.println("dList size : " + dList.size());

		return "mypage/itineraryForm";

	}

	// 일정 적기 insert
	@RequestMapping(value = "/mypage/itinerarylist.hush", method = { RequestMethod.GET })
	public String itineraryList(HttpServletRequest req, HttpSession session) {

		boolean login = false;

		String id = (String) session.getAttribute("id");
		System.out.println("id : " + id);

		if (id != null) { // 로그인 되어있을 때

			List<ItineraryDTO> list = dao.itineraryList(id);
			System.out.println("itineraryList size : " + list.size());

			for (int i = 0; i < list.size(); i++) {
				ItineraryDTO dto = list.get(i);

				// 날짜 전처리
				dto.setStartDate(dto.getStartDate().substring(0, 10));
				dto.setEndDate(dto.getEndDate().substring(0, 10));

				// 성별 전처리
				String gender = dto.getGender(); // f or m

				if (gender.equals("f")) { // f
					dto.setGender("여자");
				} else { // m
					dto.setGender("남자");
				}
			}

			login = true;
			req.setAttribute("login", login); // true
			req.setAttribute("list", list);

		} else {
			req.setAttribute("login", login); // false
		}

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		return "mypage/itineraryList";
	}

	// 찜목록 리스트
	@RequestMapping(value = "/mypage/zzim/successlist.hush", method = { RequestMethod.GET })
	public String zzimSuccessList(HttpServletRequest req, HttpSession session) {

		System.out
				.println("----------------------------------성사찜하꺼야--------------------------------");

		int cnt = 0;

		Calendar now = Calendar.getInstance();
		System.out.println("now : " + String.format("%tF", now));
		now.add(Calendar.DATE, 7); // 접속날짜에서 7일 더한거

		String nowDay = String.format("%tF", now);
		System.out.println("nowDay : " + nowDay);

		HashMap<String, String> map2 = new HashMap<String, String>();

		map2.put("nowDay", nowDay);

		ZzimDTO success_dto = null; // 성사찜
		ZzimAccomDTO zzimNaccomDTO = null;

		String id = (String) session.getAttribute("id");

		if (id != null) {

			map2.put("id", id);

			// 성사찜
			ZzimDTO dto = dao.successZzim(map2);

			System.out.println("accommodationCodeNum : "
					+ dto.getAccommodationCodeNum());
			System.out.println("cnt : " + dto.getCnt());

			cnt = Integer.parseInt(dto.getCnt());

			if (cnt == 3) {
				System.out.println("성사찜입니다.");

				map2.put("accommodationCodeNum", dto.getAccommodationCodeNum());

				
				success_dto = dao.getZzim(map2);

				int p_cnt = dao.checkPayment(success_dto);
				
				if(p_cnt == 0) { //
					
					success_dto.setdDay(success_dto.getdDay().substring(0, 10));

					zzimNaccomDTO = dao.getZzimAccom(success_dto);

					zzimNaccomDTO.setdDay(zzimNaccomDTO.getdDay().substring(0, 10));
					zzimNaccomDTO.setZzimDate(zzimNaccomDTO.getZzimDate()
							.substring(0, 10));
				}
			}
		}

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		req.setAttribute("cnt", cnt);
		req.setAttribute("dto", zzimNaccomDTO);

		return "mypage/zzimSuccessList";
	}

	// 찜목록 리스트
	@RequestMapping(value = "/mypage/zzim/prelist.hush", method = { RequestMethod.GET })
	public String zzimPreList(HttpServletRequest req, HttpSession session) {

		System.out
				.println("----------------------------------대기찜하끄야--------------------------------");

		Calendar now = Calendar.getInstance();
		System.out.println("now : " + String.format("%tF", now));
		now.add(Calendar.DATE, 7); // 접속날짜에서 7일 더한거

		String nowDay = String.format("%tF", now);
		System.out.println("nowDay : " + nowDay);

		HashMap<String, String> map2 = new HashMap<String, String>();

		map2.put("nowDay", nowDay);

		List<ZzimDTO> pre_list = new ArrayList<ZzimDTO>(); // 대기찜
		List<ZzimAccomDTO> zzimNaccomList = new ArrayList<ZzimAccomDTO>();
		ZzimAccomDTO zzimNaccomDTO = null;
		List<Integer> cntList = new ArrayList<Integer>();
		int cnt = 0;

		String id = (String) session.getAttribute("id");

		if (id != null) {

			map2.put("id", id);

			// 대기찜
			pre_list = dao.preZzim(map2);
			System.out.println("pre_list size : " + pre_list.size());

			for (int i = 0; i < pre_list.size(); i++) {
				ZzimDTO dto = pre_list.get(i);

				dto.setdDay(dto.getdDay().substring(0, 10));

				cnt = dao.getCount(dto);

				zzimNaccomDTO = dao.getZzimAccom(dto);

				zzimNaccomDTO.setdDay(zzimNaccomDTO.getdDay().substring(0, 10));
				zzimNaccomDTO.setZzimDate(zzimNaccomDTO.getZzimDate()
						.substring(0, 10));

				System.out
						.println("************************************************");
				System.out.println("mainImg : " + zzimNaccomDTO.getMainImg());
				System.out.println("name : " + zzimNaccomDTO.getName());
				System.out.println("zzimDate : " + zzimNaccomDTO.getZzimDate());
				System.out.println("dDay : " + zzimNaccomDTO.getdDay());
				System.out.println("price : " + zzimNaccomDTO.getPrice());
				System.out
						.println("************************************************");

				zzimNaccomList.add(zzimNaccomDTO);
				cntList.add(cnt);

			}

			System.out
					.println("zzimNaccomList size : " + zzimNaccomList.size());

		}

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		req.setAttribute("cntList", cntList);
		req.setAttribute("list", zzimNaccomList);

		return "mypage/zzimPreList";
	}

	// 찜목록 리스트
	@RequestMapping(value = "/mypage/zzim/faillist.hush", method = { RequestMethod.GET })
	public String zzimFailList(HttpServletRequest req, HttpSession session) {

		System.out
				.println("----------------------------------실패찜하꺼야--------------------------------");

		Calendar now = Calendar.getInstance();
		System.out.println("now : " + String.format("%tF", now));
		now.add(Calendar.DATE, 7); // 접속날짜에서 7일 더한거

		String nowDay = String.format("%tF", now);
		System.out.println("nowDay : " + nowDay);

		HashMap<String, String> map2 = new HashMap<String, String>();
		List<ZzimAccomDTO> zzimNaccomList = new ArrayList<ZzimAccomDTO>();
		List<Integer> cntList = new ArrayList<Integer>();
		int cnt = 0;
		ZzimAccomDTO zzimNaccomDTO = null;

		map2.put("nowDay", nowDay);

		List<ZzimDTO> id_list = new ArrayList<ZzimDTO>(); // 실패 or 완료 찜

		String id = (String) session.getAttribute("id");

		if (id != null) {

			map2.put("id", id);

			// 완료 or 실패찜
			id_list = dao.getIdZzim(map2);
			System.out.println("id_list size : " + id_list.size());

			// 실패찜
			for (int i = 0; i < id_list.size(); i++) {
				ZzimDTO dto = id_list.get(i);

				dto.setdDay(dto.getdDay().substring(0, 10));

				ZzimDTO dto2 = dao.failZzim(dto);

				cnt = Integer.parseInt(dto2.getCnt());
				System.out.println("★★★★★★★★★★★★★★★★★★★★★★★");
				System.out.println("cnt : " + cnt);
				System.out.println("★★★★★★★★★★★★★★★★★★★★★★★");

				if (cnt < 3) {

					cntList.add(cnt);

					zzimNaccomDTO = dao.getZzimAccom(dto);

					zzimNaccomDTO.setdDay(zzimNaccomDTO.getdDay().substring(0,
							10));
					zzimNaccomDTO.setZzimDate(zzimNaccomDTO.getZzimDate()
							.substring(0, 10));

					System.out
							.println("************************************************");
					System.out.println("mainImg : "
							+ zzimNaccomDTO.getMainImg());
					System.out.println("name : " + zzimNaccomDTO.getName());
					System.out.println("zzimDate : "
							+ zzimNaccomDTO.getZzimDate());
					System.out.println("dDay : " + zzimNaccomDTO.getdDay());
					System.out.println("price : " + zzimNaccomDTO.getPrice());
					System.out
							.println("************************************************");

					zzimNaccomList.add(zzimNaccomDTO);

				}
			}

			System.out
					.println("zzimNaccomList size : " + zzimNaccomList.size());
		}

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		req.setAttribute("cntList", cntList);
		req.setAttribute("list", zzimNaccomList);

		return "mypage/zzimFailList";
	}

	@RequestMapping(value = "/mypage/message.hush", method = { RequestMethod.GET })
	public String message(HttpServletRequest req, HttpSession session) {

		String id = (String) session.getAttribute("id");
		System.out.println("id : " + id);

		List<MessageDTO> list = dao.getMessage(id);

		for (int i = 0; i < list.size(); i++) {
			MessageDTO dto = list.get(i);

			dto.setRegDate(dto.getRegDate().substring(0, 10));
		}

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));

		req.setAttribute("list", list);

		return "mypage/message";
	}

	@RequestMapping(value = "/mypage/messageview.hush", method = { RequestMethod.GET })
	public String messageview(HttpServletRequest req, HttpSession session,
			String seq) {

		String id = (String) session.getAttribute("id");

		MessageDTO dto = dao.getMessageView(seq);

		dto.setId(id);

		// System.out.println("뭐지 ? : " + dto.getMessage());
		dto.setRegDate(dto.getRegDate().substring(0, 10));
		dto.setMessage(dto.getMessage().replace("\n", "<br />"));
		// System.out.println("dddddd : " + dto.getMessage());

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		req.setAttribute("msgdto", dto);

		return "mypage/messageView";
	}

	@RequestMapping(value = "/mypage/paymentcheck.hush", method = { RequestMethod.GET })
	public String paymentCheck(HttpServletRequest req, HttpSession session) {

		String id = (String) session.getAttribute("id");

		// 체크박스 / image / name / address / dday / price

		List<PaymentCheckDTO> list = null;

		if (id != null) {
			list = dao.paymentCheck(id);

			for (int i = 0; i < list.size(); i++) {

				PaymentCheckDTO dto = list.get(i);
				dto.setdDay(dto.getdDay().substring(0, 10));
			}
		}

		map = menu.menu(session);

		req.setAttribute("memberdto", map.get("memberdto"));
		req.setAttribute("msgList", map.get("msgList"));
		req.setAttribute("list", list);

		return "mypage/paymentCheck";
	}

}
