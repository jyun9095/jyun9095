package com.hush.mypage;

public class ZzimAccomDTO {

	//zzim
	private String seq;
	private String id;
	private String accommodationCodeNum;
	private String zzimDate;
	private String dDay;

	//accommodation
	private String codeNum;
	private String regionSeq;
	private String name;
	private String address;
	private String latitude; // 위도
	private String longitude;// 경도
	private String mainImg;
	private String checkIn;
	private String checkOut;
	private int price;
	private String breakFirst;
	private String totalZzim;
	private String bathroom;
	private String bed;
	private String room;
	private String city;
	private String region;
	private String gender;
	
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAccommodationCodeNum() {
		return accommodationCodeNum;
	}
	public void setAccommodationCodeNum(String accommodationCodeNum) {
		this.accommodationCodeNum = accommodationCodeNum;
	}
	public String getZzimDate() {
		return zzimDate;
	}
	public void setZzimDate(String zzimDate) {
		this.zzimDate = zzimDate;
	}
	public String getdDay() {
		return dDay;
	}
	public void setdDay(String dDay) {
		this.dDay = dDay;
	}
	public String getCodeNum() {
		return codeNum;
	}
	public void setCodeNum(String codeNum) {
		this.codeNum = codeNum;
	}
	public String getRegionSeq() {
		return regionSeq;
	}
	public void setRegionSeq(String regionSeq) {
		this.regionSeq = regionSeq;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getMainImg() {
		return mainImg;
	}
	public void setMainImg(String mainImg) {
		this.mainImg = mainImg;
	}
	public String getCheckIn() {
		return checkIn;
	}
	public void setCheckIn(String checkIn) {
		this.checkIn = checkIn;
	}
	public String getCheckOut() {
		return checkOut;
	}
	public void setCheckOut(String checkOut) {
		this.checkOut = checkOut;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getBreakFirst() {
		return breakFirst;
	}
	public void setBreakFirst(String breakFirst) {
		this.breakFirst = breakFirst;
	}
	public String getTotalZzim() {
		return totalZzim;
	}
	public void setTotalZzim(String totalZzim) {
		this.totalZzim = totalZzim;
	}
	public String getBathroom() {
		return bathroom;
	}
	public void setBathroom(String bathroom) {
		this.bathroom = bathroom;
	}
	public String getBed() {
		return bed;
	}
	public void setBed(String bed) {
		this.bed = bed;
	}
	public String getRoom() {
		return room;
	}
	public void setRoom(String room) {
		this.room = room;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
}
