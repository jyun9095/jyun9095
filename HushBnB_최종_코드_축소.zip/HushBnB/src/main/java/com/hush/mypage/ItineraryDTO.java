package com.hush.mypage;

public class ItineraryDTO {
	
	private String seq;
	private String id;
	private String destination;
	private String startDate;
	private String endDate;
	private String peopleNum;
	private String price;
	private String gender;
	
	//DB외의 데이터
	private String citySeq; 
	private String regionSeq;
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getPeopleNum() {
		return peopleNum;
	}
	public void setPeopleNum(String peopleNum) {
		this.peopleNum = peopleNum;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCitySeq() {
		return citySeq;
	}
	public void setCitySeq(String citySeq) {
		this.citySeq = citySeq;
	}
	public String getRegionSeq() {
		return regionSeq;
	}
	public void setRegionSeq(String regionSeq) {
		this.regionSeq = regionSeq;
	}
	
}
